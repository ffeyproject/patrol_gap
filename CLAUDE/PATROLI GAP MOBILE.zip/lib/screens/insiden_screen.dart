import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import 'incident_detail_screen.dart';
import 'report_incident_screen.dart';

class InsidenScreen extends StatefulWidget {
  final AppUser user;

  const InsidenScreen({
    super.key,
    required this.user,
  });

  @override
  State<InsidenScreen> createState() => _InsidenScreenState();
}

class _InsidenScreenState extends State<InsidenScreen> {
  List<IncidentModel> _incidents = [];

  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) {
      setState(() {
        _loading = true;
      });
    }

    try {
      final res = await ApiService.instance.get(
        'getIncidents',
      );

      if (!mounted) return;

      List<IncidentModel> incidents = [];

      if (res['success'] == true && res['data'] is List) {
        incidents = (res['data'] as List)
            .map(
              (e) => IncidentModel.fromJson(
                Map<String, dynamic>.from(e as Map),
              ),
            )
            .toList();
      }

      setState(() {
        _loading = false;
        _incidents = incidents;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _loading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text(
            'Gagal memuat laporan insiden. Periksa koneksi internet.',
          ),
        ),
      );
    }
  }

  Future<void> _reportIncident() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ReportIncidentScreen(
          user: widget.user,
        ),
      ),
    );

    if (result == true && mounted) {
      await _load();
    }
  }

  Color _severityColor(String title) {
    final value = title.toLowerCase().trim();

    if (value.contains('kebakaran') ||
        value.contains('pencurian') ||
        value.contains('kecelakaan') ||
        value.contains('perkelahian') ||
        value.contains('ancaman')) {
      return AppColors.danger;
    }

    if (value.contains('kerusakan') ||
        value.contains('gangguan') ||
        value.contains('kehilangan')) {
      return AppColors.warning;
    }

    return AppColors.primary;
  }

  String _severityLabel(String title) {
    final value = title.toLowerCase().trim();

    if (value.contains('kebakaran') ||
        value.contains('pencurian') ||
        value.contains('kecelakaan') ||
        value.contains('perkelahian') ||
        value.contains('ancaman')) {
      return 'URGENT';
    }

    if (value.contains('kerusakan') ||
        value.contains('gangguan') ||
        value.contains('kehilangan')) {
      return 'PERHATIAN';
    }

    return 'LAPORAN';
  }

  String _formatTime(String timestamp) {
    if (timestamp.trim().isEmpty) {
      return '--:--';
    }

    final parts = timestamp.trim().split(' ');

    if (parts.length > 1) {
      final time = parts[1];

      if (time.length >= 5) {
        return time.substring(0, 5);
      }

      return time;
    }

    return timestamp.length >= 5 ? timestamp.substring(0, 5) : timestamp;
  }

  String _formatDate(String timestamp) {
    if (timestamp.trim().isEmpty) {
      return '';
    }

    final parts = timestamp.trim().split(' ');

    if (parts.isNotEmpty) {
      return parts[0];
    }

    return '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: _buildAppBar(),
      floatingActionButton: _loading
          ? null
          : FloatingActionButton.extended(
              onPressed: _reportIncident,
              backgroundColor: AppColors.danger,
              foregroundColor: Colors.white,
              elevation: 5,
              icon: const Icon(
                Icons.add_alert_rounded,
              ),
              label: const Text(
                'Lapor Insiden',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
      body: RefreshIndicator(
        color: AppColors.danger,
        onRefresh: _load,
        child: _loading
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : _incidents.isEmpty
                ? _buildEmptyState()
                : ListView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(
                      16,
                      10,
                      16,
                      100,
                    ),
                    children: [
                      _buildOverviewCard(),
                      const SizedBox(height: 24),
                      _buildSectionHeader(),
                      const SizedBox(height: 12),
                      ..._incidents.asMap().entries.map(
                        (entry) {
                          final index = entry.key;
                          final incident = entry.value;

                          return _IncidentCard(
                            number: index + 1,
                            incident: incident,
                            color: _severityColor(
                              incident.title,
                            ),
                            severity: _severityLabel(
                              incident.title,
                            ),
                            time: _formatTime(
                              incident.timestamp,
                            ),
                            date: _formatDate(
                              incident.timestamp,
                            ),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => IncidentDetailScreen(
                                    incident: incident,
                                    color: _severityColor(incident.title),
                                    severity: _severityLabel(incident.title),
                                  ),
                                ),
                              );
                            },
                          );
                        },
                      ),
                    ],
                  ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppColors.bg,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      titleSpacing: 16,
      title: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Laporan Insiden',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          SizedBox(height: 2),
          Text(
            'Pantau kejadian di area kerja',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w400,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOverviewCard() {
    final count = _incidents.length;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            AppColors.danger,
            Color(0xFFB91C1C),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(21),
        boxShadow: [
          BoxShadow(
            color: AppColors.danger.withValues(alpha: 0.18),
            blurRadius: 18,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.13),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(
              Icons.warning_amber_rounded,
              color: Colors.white,
              size: 27,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'TOTAL LAPORAN',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.7,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '$count Insiden',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 2),
                const Text(
                  'Laporan yang tercatat',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 7,
            ),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Row(
              children: [
                Icon(
                  Icons.shield_outlined,
                  color: Colors.white,
                  size: 14,
                ),
                SizedBox(width: 5),
                Text(
                  'MONITOR',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Riwayat Insiden',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
              SizedBox(height: 3),
              Text(
                'Daftar kejadian yang telah dilaporkan',
                style: TextStyle(
                  fontSize: 11,
                  color: AppColors.textSecondary,
                ),
              ),
            ],
          ),
        ),
        Text(
          '${_incidents.length} laporan',
          style: const TextStyle(
            fontSize: 10.5,
            fontWeight: FontWeight.w600,
            color: AppColors.textSecondary,
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        const SizedBox(height: 80),
        Center(
          child: Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              color: AppColors.success.withValues(alpha: 0.10),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.verified_user_outlined,
              size: 38,
              color: AppColors.success,
            ),
          ),
        ),
        const SizedBox(height: 18),
        const Center(
          child: Text(
            'Tidak Ada Insiden',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
        ),
        const SizedBox(height: 7),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 45),
          child: Text(
            'Belum ada laporan insiden yang tercatat. Kondisi area terpantau aman.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 11.5,
              color: AppColors.textSecondary,
              height: 1.5,
            ),
          ),
        ),
        const SizedBox(height: 24),
        Center(
          child: OutlinedButton.icon(
            onPressed: _reportIncident,
            icon: const Icon(
              Icons.add_alert_rounded,
              size: 18,
            ),
            label: const Text(
              'Buat Laporan',
            ),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.danger,
              side: BorderSide(
                color: AppColors.danger.withValues(alpha: 0.3),
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ============================================================
// INCIDENT CARD
// ============================================================

class _IncidentCard extends StatelessWidget {
  final int number;
  final IncidentModel incident;
  final Color color;
  final String severity;
  final String time;
  final String date;
  final VoidCallback? onTap;

  const _IncidentCard({
    required this.number,
    required this.incident,
    required this.color,
    required this.severity,
    required this.time,
    required this.date,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 11),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(
          color: AppColors.border,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(17),
        child: InkWell(
          onTap: onTap,
          child: IntrinsicHeight(
          child: Row(
            children: [
              Container(
                width: 4,
                color: color,
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 42,
                            height: 42,
                            decoration: BoxDecoration(
                              color: color.withValues(alpha: 0.10),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Icon(
                              Icons.warning_amber_rounded,
                              color: color,
                              size: 22,
                            ),
                          ),
                          const SizedBox(width: 11),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        incident.title,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontSize: 13.5,
                                          fontWeight: FontWeight.w700,
                                          color: AppColors.textPrimary,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    _SeverityBadge(
                                      text: severity,
                                      color: color,
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 5),
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.access_time_rounded,
                                      size: 13,
                                      color: AppColors.textSecondary,
                                    ),
                                    const SizedBox(width: 4),
                                    Text(
                                      time,
                                      style: const TextStyle(
                                        fontSize: 10.5,
                                        color: AppColors.textSecondary,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    if (date.isNotEmpty) ...[
                                      const SizedBox(width: 8),
                                      const Text(
                                        '•',
                                        style: TextStyle(
                                          color: AppColors.textSecondary,
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(
                                          date,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            fontSize: 10.5,
                                            color: AppColors.textSecondary,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 13),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(11),
                        decoration: BoxDecoration(
                          color: AppColors.bg,
                          borderRadius: BorderRadius.circular(11),
                        ),
                        child: Text(
                          incident.description,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 11.5,
                            color: AppColors.textSecondary,
                            height: 1.45,
                          ),
                        ),
                      ),
                      const SizedBox(height: 11),
                      Row(
                        children: [
                          Container(
                            width: 25,
                            height: 25,
                            decoration: BoxDecoration(
                              color: AppColors.primary.withValues(alpha: 0.08),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.person_outline_rounded,
                              size: 14,
                              color: AppColors.primary,
                            ),
                          ),
                          const SizedBox(width: 7),
                          const Text(
                            'Dilaporkan oleh',
                            style: TextStyle(
                              fontSize: 9.5,
                              color: AppColors.textSecondary,
                            ),
                          ),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              incident.userId,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w600,
                                color: AppColors.textPrimary,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      ),
    );
  }
}

// ============================================================
// SEVERITY BADGE
// ============================================================

class _SeverityBadge extends StatelessWidget {
  final String text;
  final Color color;

  const _SeverityBadge({
    required this.text,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 7,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontSize: 8,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.3,
        ),
      ),
    );
  }
}
