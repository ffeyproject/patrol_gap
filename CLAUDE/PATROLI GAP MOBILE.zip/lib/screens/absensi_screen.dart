import 'dart:convert';
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show PlatformException;
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

import '../models/models.dart';
import '../services/api_service.dart';
import '../services/location_service.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';

class AbsensiScreen extends StatefulWidget {
  final AppUser user;

  const AbsensiScreen({
    super.key,
    required this.user,
  });

  @override
  State<AbsensiScreen> createState() => _AbsensiScreenState();
}

class _AbsensiScreenState extends State<AbsensiScreen> {
  CameraController? _cameraController;

  bool _cameraReady = false;
  bool _processing = false;

  String? _statusMessage;
  bool _statusIsError = false;

  late final FaceDetector _faceDetector;

  @override
  void initState() {
    super.initState();

    _faceDetector = FaceDetector(
      options: FaceDetectorOptions(
        performanceMode: FaceDetectorMode.fast,
        enableTracking: false,
        enableClassification: false,
        enableLandmarks: false,
        enableContours: false,
      ),
    );

    _initializeCamera();
  }

  // ============================================================
  // CAMERA
  // ============================================================

  Future<void> _initializeCamera() async {
    try {
      final cameras = await availableCameras();

      if (cameras.isEmpty) {
        throw Exception(
          'Kamera tidak tersedia pada perangkat ini.',
        );
      }

      CameraDescription selectedCamera;

      try {
        selectedCamera = cameras.firstWhere(
          (camera) => camera.lensDirection == CameraLensDirection.front,
        );
      } catch (_) {
        selectedCamera = cameras.first;
      }

      final controller = CameraController(
        selectedCamera,
        ResolutionPreset.medium,
        enableAudio: false,
      );

      await controller.initialize();

      if (!mounted) {
        await controller.dispose();
        return;
      }

      setState(() {
        _cameraController = controller;
        _cameraReady = true;
        _statusMessage = null;
        _statusIsError = false;
      });
    } on CameraException catch (e) {
      if (!mounted) return;

      setState(() {
        _cameraReady = false;
        _statusIsError = true;
        _statusMessage = _cameraErrorMessage(e);
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _cameraReady = false;
        _statusIsError = true;
        _statusMessage = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  String _cameraErrorMessage(CameraException e) {
    switch (e.code) {
      case 'CameraAccessDenied':
        return 'Izin kamera ditolak. Silakan izinkan akses kamera di pengaturan perangkat.';
      case 'CameraAccessDeniedWithoutPrompt':
        return 'Akses kamera ditolak. Silakan aktifkan izin kamera melalui pengaturan perangkat.';
      case 'CameraAccessRestricted':
        return 'Akses kamera dibatasi oleh perangkat.';
      case 'cameraNotFound':
        return 'Kamera tidak ditemukan pada perangkat ini.';
      default:
        return 'Kamera tidak dapat digunakan. Pastikan izin kamera telah diberikan.';
    }
  }

  // ============================================================
  // FACE DETECTION
  // ============================================================

  Future<bool> _validateFace(String imagePath) async {
    try {
      final inputImage = InputImage.fromFilePath(
        imagePath,
      );

      final faces = await _faceDetector.processImage(
        inputImage,
      );

      if (faces.isEmpty) {
        throw Exception(
          'Wajah tidak terdeteksi. Posisikan wajah di tengah kamera dan pastikan pencahayaan cukup.',
        );
      }

      if (faces.length > 1) {
        throw Exception(
          'Terdeteksi lebih dari satu wajah. Pastikan hanya wajah petugas yang terlihat.',
        );
      }

      return true;
    } on PlatformException catch (e) {
      debugPrint(
        'ML Kit Face Detection PlatformException: $e',
      );

      // Jika ML Kit mengalami masalah pada perangkat tertentu,
      // foto tetap dapat digunakan sebagai bukti absensi.
      return true;
    } catch (e) {
      rethrow;
    }
  }

  // ============================================================
  // SUBMIT ABSENSI
  // ============================================================

  Future<void> _submitAttendance(String type) async {
    if (_processing) return;

    final controller = _cameraController;

    if (controller == null || !controller.value.isInitialized) {
      _showError(
        'Kamera belum siap. Silakan tunggu beberapa saat.',
      );
      return;
    }

    setState(() {
      _processing = true;
      _statusMessage = null;
      _statusIsError = false;
    });

    try {
      // --------------------------------------------------------
      // 1. AMBIL FOTO
      // --------------------------------------------------------

      final picture = await controller.takePicture();

      if (!mounted) return;

      // --------------------------------------------------------
      // 2. VALIDASI WAJAH
      // --------------------------------------------------------

      await _validateFace(picture.path);

      if (!mounted) return;

      // --------------------------------------------------------
      // 3. AMBIL LOKASI GPS
      // --------------------------------------------------------

      final position = await LocationService.instance.getCurrentPosition();

      if (!mounted) return;

      // --------------------------------------------------------
      // 4. BACA FOTO
      // --------------------------------------------------------

      final imageFile = File(picture.path);

      final bytes = await imageFile.readAsBytes();

      final base64Image = 'data:image/jpeg;base64,${base64Encode(bytes)}';

      // --------------------------------------------------------
      // 5. TENTUKAN ENDPOINT
      // --------------------------------------------------------

      final endpoint = type == 'CHECK_IN' ? 'checkIn' : 'checkOut';

      // --------------------------------------------------------
      // 6. KIRIM KE SERVER
      // --------------------------------------------------------

      final response = await ApiService.instance.post(
        endpoint,
        {
          'user_id': widget.user.userId,
          'lat': position.latitude,
          'long': position.longitude,
          'face_photo_base64': base64Image,
        },
      );

      if (!mounted) return;

      final success = response['success'] == true;

      // --------------------------------------------------------
      // 7. HASIL
      // --------------------------------------------------------

      if (success) {
        setState(() {
          _processing = false;
          _statusIsError = false;
          _statusMessage = type == 'CHECK_IN'
              ? 'Check-in berhasil dicatat.'
              : 'Check-out berhasil dicatat.';
        });

        await Future.delayed(
          const Duration(milliseconds: 1200),
        );

        if (!mounted) return;

        Navigator.pop(context, true);
      } else {
        setState(() {
          _processing = false;
          _statusIsError = true;
          _statusMessage =
              response['message']?.toString() ?? 'Absensi gagal disimpan.';
        });
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _processing = false;
        _statusIsError = true;
        _statusMessage = _cleanErrorMessage(e);
      });
    }
  }

  String _cleanErrorMessage(Object error) {
    final message = error.toString().replaceFirst('Exception: ', '').trim();

    if (message.isEmpty) {
      return 'Terjadi kesalahan saat memproses absensi.';
    }

    return message;
  }

  // ============================================================
  // ERROR SNACKBAR
  // ============================================================

  void _showError(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).hideCurrentSnackBar();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: AppColors.danger,
        margin: const EdgeInsets.fromLTRB(
          16,
          0,
          16,
          16,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        content: Row(
          children: [
            const Icon(
              Icons.error_outline_rounded,
              color: Colors.white,
              size: 21,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    _cameraController?.dispose();
    _faceDetector.close();
    super.dispose();
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            Expanded(
              child: _buildCameraSection(),
            ),
            _buildBottomPanel(),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // HEADER
  // ============================================================

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      color: Colors.black,
      padding: const EdgeInsets.fromLTRB(
        8,
        8,
        16,
        12,
      ),
      child: Row(
        children: [
          IconButton(
            tooltip: 'Kembali',
            onPressed: _processing ? null : () => Navigator.pop(context),
            icon: Icon(
              Icons.arrow_back_rounded,
              color: _processing ? Colors.white24 : Colors.white,
            ),
          ),
          const SizedBox(width: 4),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Absensi Petugas',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(height: 3),
                Text(
                  'Verifikasi wajah dan lokasi',
                  style: TextStyle(
                    color: Colors.white60,
                    fontSize: 11.5,
                  ),
                ),
              ],
            ),
          ),
          _buildCameraStatus(),
        ],
      ),
    );
  }

  Widget _buildCameraStatus() {
    final ready = _cameraReady;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.10),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(
              color: ready ? AppColors.success : AppColors.warning,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 6),
          Text(
            ready ? 'Kamera siap' : 'Menyiapkan',
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 10.5,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // CAMERA SECTION
  // ============================================================

  Widget _buildCameraSection() {
    return Container(
      width: double.infinity,
      color: Colors.black,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // CAMERA
          if (_cameraReady && _cameraController != null)
            Positioned.fill(
              child: _buildCameraPreview(),
            )
          else
            _buildCameraLoading(),

          // DARK OVERLAY
          if (_cameraReady)
            Positioned.fill(
              child: IgnorePointer(
                child: Container(
                  color: Colors.black.withValues(alpha: 0.13),
                ),
              ),
            ),

          // FACE FRAME
          if (_cameraReady)
            const IgnorePointer(
              child: _FaceScannerFrame(),
            ),

          // INSTRUCTION
          if (_cameraReady)
            Positioned(
              top: 20,
              left: 18,
              right: 18,
              child: _buildInstruction(),
            ),

          // PROCESSING
          if (_processing)
            Positioned.fill(
              child: _buildProcessingOverlay(),
            ),
        ],
      ),
    );
  }

  Widget _buildCameraPreview() {
    final controller = _cameraController!;

    final previewSize = controller.value.previewSize;

    if (previewSize == null) {
      return CameraPreview(controller);
    }

    return ClipRect(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: previewSize.height,
          height: previewSize.width,
          child: CameraPreview(controller),
        ),
      ),
    );
  }

  Widget _buildCameraLoading() {
    return const Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 38,
            height: 38,
            child: CircularProgressIndicator(
              color: Colors.white,
              strokeWidth: 2.5,
            ),
          ),
          SizedBox(height: 16),
          Text(
            'Menyiapkan kamera...',
            style: TextStyle(
              color: Colors.white70,
              fontSize: 12.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInstruction() {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 11,
      ),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.48),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.12),
        ),
      ),
      child: const Row(
        children: [
          Icon(
            Icons.face_retouching_natural_rounded,
            color: Colors.white,
            size: 21,
          ),
          SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Posisikan wajah di dalam bingkai',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 3),
                Text(
                  'Pastikan wajah terlihat jelas dan pencahayaan cukup',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 10.5,
                    height: 1.3,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProcessingOverlay() {
    return Container(
      color: Colors.black.withValues(alpha: 0.62),
      child: const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 44,
              height: 44,
              child: CircularProgressIndicator(
                color: Colors.white,
                strokeWidth: 3,
              ),
            ),
            SizedBox(height: 17),
            Text(
              'Memproses absensi...',
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 5),
            Text(
              'Memverifikasi foto dan lokasi GPS',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 11.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // BOTTOM PANEL
  // ============================================================

  Widget _buildBottomPanel() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(
        20,
        19,
        20,
        22,
      ),
      decoration: const BoxDecoration(
        color: AppColors.bg,
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(28),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildUserInfo(),
          const SizedBox(height: 15),
          if (_statusMessage != null) ...[
            _buildStatusMessage(),
            const SizedBox(height: 13),
          ],
          _buildLocationInfo(),
          const SizedBox(height: 17),
          _buildActionButtons(),
        ],
      ),
    );
  }

  // ============================================================
  // USER INFO
  // ============================================================

  Widget _buildUserInfo() {
    return Row(
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: AppColors.primary.withValues(alpha: 0.10),
            borderRadius: BorderRadius.circular(13),
          ),
          child: const Icon(
            Icons.badge_outlined,
            color: AppColors.primary,
            size: 23,
          ),
        ),
        const SizedBox(width: 11),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.user.fullName,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                '@${widget.user.username} • Site ${widget.user.assignedSiteId}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppColors.textSecondary,
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ============================================================
  // LOCATION INFO
  // ============================================================

  Widget _buildLocationInfo() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 10,
      ),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppColors.border,
        ),
      ),
      child: const Row(
        children: [
          Icon(
            Icons.location_on_outlined,
            color: AppColors.primary,
            size: 19,
          ),
          SizedBox(width: 9),
          Expanded(
            child: Text(
              'Lokasi GPS akan diverifikasi berdasarkan radius site.',
              style: TextStyle(
                color: AppColors.textSecondary,
                fontSize: 10.8,
                height: 1.35,
              ),
            ),
          ),
          Icon(
            Icons.verified_outlined,
            color: AppColors.success,
            size: 17,
          ),
        ],
      ),
    );
  }

  // ============================================================
  // STATUS
  // ============================================================

  Widget _buildStatusMessage() {
    final color = _statusIsError ? AppColors.danger : AppColors.success;

    final icon = _statusIsError
        ? Icons.error_outline_rounded
        : Icons.check_circle_outline_rounded;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 11,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: color.withValues(alpha: 0.18),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            icon,
            color: color,
            size: 19,
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              _statusMessage!,
              style: TextStyle(
                color: color,
                fontSize: 11.8,
                fontWeight: FontWeight.w500,
                height: 1.35,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // BUTTONS
  // ============================================================

  Widget _buildActionButtons() {
    return Row(
      children: [
        Expanded(
          child: SizedBox(
            height: 52,
            child: LoadingButton(
              loading: _processing,
              label: 'Check-In',
              onPressed: _cameraReady && !_processing
                  ? () => _submitAttendance('CHECK_IN')
                  : null,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: SizedBox(
            height: 52,
            child: OutlinedButton.icon(
              onPressed: _cameraReady && !_processing
                  ? () => _submitAttendance('CHECK_OUT')
                  : null,
              icon: const Icon(
                Icons.logout_rounded,
                size: 19,
              ),
              label: const Text(
                'Check-Out',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.primary,
                disabledForegroundColor:
                    AppColors.textSecondary.withValues(alpha: 0.5),
                side: const BorderSide(
                  color: AppColors.border,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(13),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ================================================================
// FACE SCANNER FRAME
// ================================================================

class _FaceScannerFrame extends StatelessWidget {
  const _FaceScannerFrame();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 240,
      height: 310,
      child: CustomPaint(
        painter: _FaceFramePainter(),
      ),
    );
  }
}

class _FaceFramePainter extends CustomPainter {
  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    final paint = Paint()
      ..color = Colors.white
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    const double padding = 5;
    const double corner = 28;

    const left = padding;
    const top = padding;
    final right = size.width - padding;
    final bottom = size.height - padding;

    // TOP LEFT
    canvas.drawLine(
      Offset(left, top + corner),
      Offset(left, top),
      paint,
    );

    canvas.drawLine(
      Offset(left, top),
      Offset(left + corner, top),
      paint,
    );

    // TOP RIGHT
    canvas.drawLine(
      Offset(right - corner, top),
      Offset(right, top),
      paint,
    );

    canvas.drawLine(
      Offset(right, top),
      Offset(right, top + corner),
      paint,
    );

    // BOTTOM LEFT
    canvas.drawLine(
      Offset(left, bottom - corner),
      Offset(left, bottom),
      paint,
    );

    canvas.drawLine(
      Offset(left, bottom),
      Offset(left + corner, bottom),
      paint,
    );

    // BOTTOM RIGHT
    canvas.drawLine(
      Offset(right - corner, bottom),
      Offset(right, bottom),
      paint,
    );

    canvas.drawLine(
      Offset(right, bottom),
      Offset(right, bottom - corner),
      paint,
    );
  }

  @override
  bool shouldRepaint(
    covariant CustomPainter oldDelegate,
  ) {
    return false;
  }
}
