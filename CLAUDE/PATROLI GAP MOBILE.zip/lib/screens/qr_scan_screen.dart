import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../models/models.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import 'patrol_confirm_screen.dart';

class QrScanScreen extends StatefulWidget {
  final AppUser user;

  const QrScanScreen({
    super.key,
    required this.user,
  });

  @override
  State<QrScanScreen> createState() => _QrScanScreenState();
}

class _QrScanScreenState extends State<QrScanScreen> {
  late final MobileScannerController _controller;

  bool _handled = false;
  bool _checking = false;
  bool _torchEnabled = false;

  String? _error;

  @override
  void initState() {
    super.initState();

    _controller = MobileScannerController(
      detectionSpeed: DetectionSpeed.noDuplicates,
      detectionTimeoutMs: 800,
      facing: CameraFacing.back,
      torchEnabled: false,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  // ============================================================
  // SCAN QR
  // ============================================================

  Future<void> _onDetect(BarcodeCapture capture) async {
    if (_handled || _checking) return;

    if (capture.barcodes.isEmpty) return;

    String? code;

    for (final barcode in capture.barcodes) {
      final rawValue = barcode.rawValue?.trim();

      if (rawValue != null && rawValue.isNotEmpty) {
        code = rawValue;
        break;
      }
    }

    if (code == null || code.isEmpty) return;

    await _validateQr(code);
  }

  // ============================================================
  // VALIDASI QR
  // ============================================================

  Future<void> _validateQr(String code) async {
    if (_checking || _handled) return;

    if (!mounted) return;

    setState(() {
      _checking = true;
      _error = null;
    });

    try {
      // Pause scanner sementara proses validasi.
      try {
        await _controller.stop();
      } catch (_) {}

      final res = await ApiService.instance.get(
        'getCheckpoints',
        {
          'site_id': widget.user.assignedSiteId,
        },
      );

      if (!mounted) return;

      // --------------------------------------------------------
      // API ERROR
      // --------------------------------------------------------

      if (res['success'] != true) {
        await _showError(
          res['message']?.toString() ?? 'Gagal mengambil data checkpoint.',
        );
        return;
      }

      // --------------------------------------------------------
      // VALIDASI DATA
      // --------------------------------------------------------

      final rawData = res['data'];

      if (rawData is! List) {
        await _showError(
          'Data checkpoint dari server tidak valid.',
        );
        return;
      }

      final List<CheckpointModel> checkpoints = [];

      for (final item in rawData) {
        try {
          if (item is Map) {
            checkpoints.add(
              CheckpointModel.fromJson(
                Map<String, dynamic>.from(item),
              ),
            );
          }
        } catch (_) {
          // Lewati data checkpoint yang rusak.
        }
      }

      // --------------------------------------------------------
      // CARI CHECKPOINT
      // --------------------------------------------------------

      CheckpointModel? matchedCheckpoint;

      for (final checkpoint in checkpoints) {
        if (checkpoint.qrCodeVal.trim() == code.trim()) {
          matchedCheckpoint = checkpoint;
          break;
        }
      }

      // --------------------------------------------------------
      // QR TIDAK DIKENALI
      // --------------------------------------------------------

      if (matchedCheckpoint == null) {
        await _showError(
          'QR Code tidak dikenali sebagai titik checkpoint di site ini.',
        );
        return;
      }

      // --------------------------------------------------------
      // CHECKPOINT VALID
      // --------------------------------------------------------

      _handled = true;

      if (!mounted) return;

      // Beri sedikit waktu agar animasi scanner berhenti dengan rapi.
      await Future.delayed(
        const Duration(milliseconds: 150),
      );

      if (!mounted) return;

      final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PatrolConfirmScreen(
            user: widget.user,
            checkpoint: matchedCheckpoint!,
          ),
        ),
      );

      if (!mounted) return;

      // Kembali ke halaman Patroli.
      Navigator.pop(
        context,
        result == true,
      );
    } catch (e) {
      if (!mounted) return;

      await _showError(
        'Terjadi kesalahan saat memvalidasi QR Code.',
      );
    }
  }

  // ============================================================
  // ERROR HANDLER
  // ============================================================

  Future<void> _showError(String message) async {
    if (!mounted) return;

    setState(() {
      _checking = false;
      _error = message;
      _handled = false;
    });

    // Jalankan scanner kembali.
    try {
      await _controller.start();
    } catch (_) {}
  }

  // ============================================================
  // TORCH
  // ============================================================

  Future<void> _toggleTorch() async {
    if (_checking) return;

    try {
      await _controller.toggleTorch();

      if (!mounted) return;

      setState(() {
        _torchEnabled = !_torchEnabled;
      });
    } catch (_) {
      // Tidak semua device mendukung flash.
    }
  }

  Widget _buildBottomPanel() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // ============================================================
        // ERROR
        // ============================================================

        if (_error != null)
          Container(
            width: double.infinity,
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 12,
            ),
            decoration: BoxDecoration(
              color: AppColors.danger.withValues(alpha: 0.94),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.15),
              ),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(
                  Icons.error_outline_rounded,
                  color: Colors.white,
                  size: 20,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    _error!,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      height: 1.35,
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                GestureDetector(
                  onTap: () {
                    setState(() {
                      _error = null;
                    });
                  },
                  child: const Icon(
                    Icons.close_rounded,
                    color: Colors.white70,
                    size: 19,
                  ),
                ),
              ],
            ),
          ),

        // ============================================================
        // INSTRUCTION
        // ============================================================

        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 13,
          ),
          decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: 0.72),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: Colors.white.withValues(alpha: 0.10),
            ),
          ),
          child: const Row(
            children: [
              Icon(
                Icons.qr_code_2_rounded,
                color: Colors.white,
                size: 28,
              ),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Arahkan kamera ke QR Code',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 3),
                    Text(
                      'Pastikan QR Code berada di dalam kotak scanner',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 11,
                        height: 1.3,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: LayoutBuilder(
        builder: (context, constraints) {
          final width = constraints.maxWidth;
          final height = constraints.maxHeight;

          // ============================================================
          // RESPONSIVE SCANNER SIZE
          // ============================================================

          final double frameSize = [
            width - 64,
            height * 0.34,
            270.0,
          ].reduce((a, b) => a < b ? a : b).clamp(190.0, 270.0);

          // ============================================================
          // AREA ATAS
          // ============================================================

          final double topSafe = MediaQuery.of(context).padding.top;

          const double topBarHeight = 70;

          final double topArea = topSafe + topBarHeight + 20;

          // ============================================================
          // AREA BAWAH
          // ============================================================

          final double bottomSafe = MediaQuery.of(context).padding.bottom;

          const double bottomPanelHeight = 125;

          final double bottomArea = bottomSafe + bottomPanelHeight + 30;

          // ============================================================
          // POSISI SCANNER
          // ============================================================

          final double availableHeight = height - topArea - bottomArea;

          final double frameTop = availableHeight > frameSize
              ? topArea + (availableHeight - frameSize) / 2
              : topArea;

          final double frameLeft = (width - frameSize) / 2;

          return Stack(
            fit: StackFit.expand,
            children: [
              // ========================================================
              // CAMERA
              // ========================================================

              MobileScanner(
                controller: _controller,
                onDetect: _onDetect,
              ),

              // ========================================================
              // DARK OVERLAY
              // ========================================================

              IgnorePointer(
                child: CustomPaint(
                  painter: _ScannerOverlayPainter(
                    frameTop: frameTop,
                    frameLeft: frameLeft,
                    frameSize: frameSize,
                  ),
                  size: Size(width, height),
                ),
              ),

              // ========================================================
              // TOP BAR
              // ========================================================

              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: SafeArea(
                  bottom: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(
                      16,
                      12,
                      16,
                      0,
                    ),
                    child: Row(
                      children: [
                        // BACK
                        _ScannerIconButton(
                          icon: Icons.arrow_back_rounded,
                          onTap: () {
                            if (Navigator.canPop(context)) {
                              Navigator.pop(context);
                            }
                          },
                        ),

                        const SizedBox(width: 12),

                        // TITLE
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 10,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.black.withValues(
                                alpha: 0.60,
                              ),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                color: Colors.white.withValues(
                                  alpha: 0.12,
                                ),
                              ),
                            ),
                            child: const Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Scan QR Checkpoint',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                SizedBox(height: 2),
                                Text(
                                  'Validasi titik patroli',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: Colors.white70,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        const SizedBox(width: 12),

                        // FLASH
                        _ScannerIconButton(
                          icon: _torchEnabled
                              ? Icons.flash_on_rounded
                              : Icons.flash_off_rounded,
                          active: _torchEnabled,
                          onTap: _toggleTorch,
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // ========================================================
              // SCANNER FRAME
              // ========================================================

              Positioned(
                top: frameTop,
                left: frameLeft,
                child: SizedBox(
                  width: frameSize,
                  height: frameSize,
                  child: Stack(
                    children: [
                      // Border
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(
                              color: Colors.white.withValues(
                                alpha: 0.20,
                              ),
                              width: 1,
                            ),
                          ),
                        ),
                      ),

                      // TOP LEFT
                      const Positioned(
                        top: 0,
                        left: 0,
                        child: _ScannerCorner(
                          top: true,
                          left: true,
                        ),
                      ),

                      // TOP RIGHT
                      const Positioned(
                        top: 0,
                        right: 0,
                        child: _ScannerCorner(
                          top: true,
                          left: false,
                        ),
                      ),

                      // BOTTOM LEFT
                      const Positioned(
                        bottom: 0,
                        left: 0,
                        child: _ScannerCorner(
                          top: false,
                          left: true,
                        ),
                      ),

                      // BOTTOM RIGHT
                      const Positioned(
                        bottom: 0,
                        right: 0,
                        child: _ScannerCorner(
                          top: false,
                          left: false,
                        ),
                      ),

                      // SCAN LINE
                      if (!_checking)
                        Positioned(
                          left: 22,
                          right: 22,
                          top: frameSize / 2,
                          child: Container(
                            height: 2,
                            decoration: BoxDecoration(
                              color: AppColors.accent,
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                  color:
                                      AppColors.accent.withValues(alpha: 0.75),
                                  blurRadius: 10,
                                  spreadRadius: 1,
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),

              // ========================================================
              // CHECKING STATUS
              // ========================================================

              if (_checking)
                Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 16,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(
                        alpha: 0.82,
                      ),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: Colors.white.withValues(
                          alpha: 0.12,
                        ),
                      ),
                    ),
                    child: const Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: 30,
                          height: 30,
                          child: CircularProgressIndicator(
                            strokeWidth: 3,
                            color: Colors.white,
                          ),
                        ),
                        SizedBox(height: 12),
                        Text(
                          'Memvalidasi QR...',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

              // ========================================================
              // BOTTOM AREA
              // ========================================================

              Positioned(
                left: 20,
                right: 20,
                bottom: 20,
                child: SafeArea(
                  top: false,
                  child: _buildBottomPanel(),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

// ================================================================
// SCANNER ICON BUTTON
// ================================================================

class _ScannerIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool active;

  const _ScannerIconButton({
    required this.icon,
    required this.onTap,
    this.active = false,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: active
          ? AppColors.accent.withValues(alpha: 0.90)
          : Colors.black.withValues(alpha: 0.55),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: Colors.white.withValues(alpha: 0.12),
            ),
          ),
          child: Icon(
            icon,
            color: Colors.white,
            size: 21,
          ),
        ),
      ),
    );
  }
}

// ================================================================
// SCANNER CORNER
// ================================================================

class _ScannerCorner extends StatelessWidget {
  final bool top;
  final bool left;

  const _ScannerCorner({
    required this.top,
    required this.left,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 42,
      height: 42,
      child: CustomPaint(
        painter: _CornerPainter(
          top: top,
          left: left,
        ),
      ),
    );
  }
}

// ================================================================
// CORNER PAINTER
// ================================================================

class _CornerPainter extends CustomPainter {
  final bool top;
  final bool left;

  _CornerPainter({
    required this.top,
    required this.left,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    final paint = Paint()
      ..color = AppColors.accent
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    final path = Path();

    final horizontalStart = left ? 2.0 : size.width - 2;
    final horizontalEnd = left ? 26.0 : size.width - 26;

    final verticalStart = top ? 2.0 : size.height - 2;
    final verticalEnd = top ? 26.0 : size.height - 26;

    // Horizontal
    path.moveTo(
      horizontalStart,
      verticalStart,
    );

    path.lineTo(
      horizontalEnd,
      verticalStart,
    );

    // Vertical
    path.moveTo(
      horizontalStart,
      verticalStart,
    );

    path.lineTo(
      horizontalStart,
      verticalEnd,
    );

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(
    covariant _CornerPainter oldDelegate,
  ) {
    return oldDelegate.top != top || oldDelegate.left != left;
  }
}

// ================================================================
// SCANNER OVERLAY
// ================================================================

class _ScannerOverlayPainter extends CustomPainter {
  final double frameTop;
  final double frameLeft;
  final double frameSize;

  _ScannerOverlayPainter({
    required this.frameTop,
    required this.frameLeft,
    required this.frameSize,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    final paint = Paint()
      ..color = Colors.black.withValues(alpha: 0.48)
      ..style = PaintingStyle.fill;

    final outer = Path()
      ..addRect(
        Rect.fromLTWH(
          0,
          0,
          size.width,
          size.height,
        ),
      );

    final inner = Path()
      ..addRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(
            frameLeft,
            frameTop,
            frameSize,
            frameSize,
          ),
          const Radius.circular(24),
        ),
      );

    final overlay = Path.combine(
      PathOperation.difference,
      outer,
      inner,
    );

    canvas.drawPath(
      overlay,
      paint,
    );
  }

  @override
  bool shouldRepaint(
    covariant _ScannerOverlayPainter oldDelegate,
  ) {
    return oldDelegate.frameTop != frameTop ||
        oldDelegate.frameLeft != frameLeft ||
        oldDelegate.frameSize != frameSize;
  }
}
