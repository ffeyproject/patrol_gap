import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../models/models.dart';
import '../services/api_service.dart';
import '../services/location_service.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';

class ReportIncidentScreen extends StatefulWidget {
  final AppUser user;

  const ReportIncidentScreen({
    super.key,
    required this.user,
  });

  @override
  State<ReportIncidentScreen> createState() => _ReportIncidentScreenState();
}

class _ReportIncidentScreenState extends State<ReportIncidentScreen> {
  final _formKey = GlobalKey<FormState>();

  final List<String> _categories = const [
    'Kebakaran',
    'Kebocoran',
    'Pencurian',
    'Kerusakan Fasilitas',
    'Lainnya',
  ];

  final TextEditingController _descCtrl = TextEditingController();

  String _category = 'Kebocoran';

  File? _photo;

  bool _submitting = false;
  bool _gettingLocation = false;

  String? _error;

  @override
  void dispose() {
    _descCtrl.dispose();
    super.dispose();
  }

  bool get _isCritical {
    return _category == 'Kebakaran' || _category == 'Pencurian';
  }

  Future<void> _takePhoto() async {
    if (_submitting) return;

    try {
      final picker = ImagePicker();

      final XFile? xfile = await picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 70,
        maxWidth: 1600,
        maxHeight: 1600,
      );

      if (xfile == null) return;

      if (!mounted) return;

      setState(() {
        _photo = File(xfile.path);
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _error = 'Tidak dapat mengambil foto. Silakan coba lagi.';
      });
    }
  }

  Future<void> _removePhoto() async {
    if (_submitting) return;

    setState(() {
      _photo = null;
    });
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();

    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (_submitting) return;

    setState(() {
      _submitting = true;
      _gettingLocation = true;
      _error = null;
    });

    try {
      // ==========================================
      // 1. AMBIL LOKASI TERKINI
      // ==========================================
      final pos = await LocationService.instance.getCurrentPosition();

      if (!mounted) return;

      setState(() {
        _gettingLocation = false;
      });

      // ==========================================
      // 2. KONVERSI FOTO KE BASE64
      // ==========================================
      String? photoBase64;

      if (_photo != null) {
        final bytes = await _photo!.readAsBytes();

        photoBase64 = 'data:image/jpeg;base64,${base64Encode(bytes)}';
      }

      // ==========================================
      // 3. KIRIM KE API
      // ==========================================
      final res = await ApiService.instance.post(
        'reportIncident',
        {
          'user_id': widget.user.userId,
          'title': _category,
          'description': _descCtrl.text.trim(),
          'lat': pos.latitude,
          'long': pos.longitude,
          if (photoBase64 != null) 'photo_base64': photoBase64,
        },
      );

      if (!mounted) return;

      // ==========================================
      // 4. BERHASIL
      // ==========================================
      if (res['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            backgroundColor: AppColors.success,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            content: const Row(
              children: [
                Icon(
                  Icons.check_circle_rounded,
                  color: Colors.white,
                ),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Laporan insiden berhasil dikirim.',
                  ),
                ),
              ],
            ),
          ),
        );

        Navigator.pop(context, true);
        return;
      }

      // ==========================================
      // 5. API ERROR
      // ==========================================
      setState(() {
        _submitting = false;
        _gettingLocation = false;
        _error =
            res['message']?.toString() ?? 'Gagal mengirim laporan insiden.';
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _submitting = false;
        _gettingLocation = false;
        _error = e.toString().replaceFirst('Exception: ', '').trim();
      });
    }
  }

  Color _categoryColor(String category) {
    switch (category) {
      case 'Kebakaran':
      case 'Pencurian':
        return AppColors.danger;

      case 'Kebocoran':
        return Colors.orange;

      case 'Kerusakan Fasilitas':
        return AppColors.warning;

      default:
        return AppColors.primary;
    }
  }

  IconData _categoryIcon(String category) {
    switch (category) {
      case 'Kebakaran':
        return Icons.local_fire_department_rounded;

      case 'Kebocoran':
        return Icons.water_drop_rounded;

      case 'Pencurian':
        return Icons.security_rounded;

      case 'Kerusakan Fasilitas':
        return Icons.construction_rounded;

      default:
        return Icons.report_problem_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final categoryColor = _categoryColor(_category);

    return Scaffold(
      backgroundColor: AppColors.bg,

      // ==========================================
      // APP BAR
      // ==========================================
      appBar: AppBar(
        title: const Text(
          'Lapor Insiden',
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
        centerTitle: false,
      ),

      // ==========================================
      // CONTENT
      // ==========================================
      body: Form(
        key: _formKey,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(
            16,
            12,
            16,
            32,
          ),
          children: [
            // ======================================
            // HEADER INFO
            // ======================================
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    AppColors.danger,
                    AppColors.danger.withValues(alpha: 0.82),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.danger.withValues(alpha: 0.18),
                    blurRadius: 18,
                    offset: const Offset(0, 7),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.16),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(
                      Icons.warning_amber_rounded,
                      color: Colors.white,
                      size: 28,
                    ),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Laporan Insiden',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Laporkan kejadian secara cepat dan akurat.',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                            height: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 22),

            // ======================================
            // SECTION: KATEGORI
            // ======================================
            const Text(
              'Kategori Kejadian',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),

            const SizedBox(height: 5),

            const Text(
              'Pilih jenis insiden yang paling sesuai.',
              style: TextStyle(
                fontSize: 12,
                color: AppColors.textSecondary,
              ),
            ),

            const SizedBox(height: 12),

            // CATEGORY GRID
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _categories.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 2.55,
              ),
              itemBuilder: (context, index) {
                final category = _categories[index];
                final selected = _category == category;
                final color = _categoryColor(category);

                return Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: _submitting
                        ? null
                        : () {
                            setState(() {
                              _category = category;
                              _error = null;
                            });
                          },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 10,
                      ),
                      decoration: BoxDecoration(
                        color: selected
                            ? color.withValues(alpha: 0.10)
                            : AppColors.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: selected ? color : AppColors.border,
                          width: selected ? 1.4 : 1,
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 34,
                            height: 34,
                            decoration: BoxDecoration(
                              color: color.withValues(alpha: 
                                selected ? 0.16 : 0.08,
                              ),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Icon(
                              _categoryIcon(category),
                              color: color,
                              size: 19,
                            ),
                          ),
                          const SizedBox(width: 9),
                          Expanded(
                            child: Text(
                              category,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: selected
                                    ? FontWeight.w700
                                    : FontWeight.w500,
                                color: selected ? color : AppColors.textPrimary,
                              ),
                            ),
                          ),
                          if (selected)
                            Icon(
                              Icons.check_circle_rounded,
                              color: color,
                              size: 18,
                            ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),

            // ======================================
            // CRITICAL WARNING
            // ======================================
            if (_isCritical) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(
                  color: AppColors.danger.withValues(alpha: 0.07),
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(
                    color: AppColors.danger.withValues(alpha: 0.18),
                  ),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(7),
                      decoration: BoxDecoration(
                        color: AppColors.danger.withValues(alpha: 0.10),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.priority_high_rounded,
                        color: AppColors.danger,
                        size: 18,
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Insiden Kritikal',
                            style: TextStyle(
                              color: AppColors.danger,
                              fontSize: 12.5,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 3),
                          Text(
                            'Kategori ini membutuhkan perhatian segera dari Danru/Supervisor.',
                            style: TextStyle(
                              color: AppColors.danger,
                              fontSize: 11.5,
                              height: 1.4,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 22),

            // ======================================
            // SECTION: DESKRIPSI
            // ======================================
            const Text(
              'Deskripsi Kejadian',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),

            const SizedBox(height: 5),

            const Text(
              'Jelaskan kejadian secara singkat, jelas, dan detail.',
              style: TextStyle(
                fontSize: 12,
                color: AppColors.textSecondary,
              ),
            ),

            const SizedBox(height: 12),

            TextFormField(
              controller: _descCtrl,
              enabled: !_submitting,
              maxLines: 5,
              minLines: 4,
              textInputAction: TextInputAction.newline,
              decoration: InputDecoration(
                hintText: 'Contoh: Ditemukan kebocoran air di area gudang...',
                hintStyle: const TextStyle(
                  fontSize: 12.5,
                  color: AppColors.textSecondary,
                ),
                alignLabelWithHint: true,
                prefixIcon: const Padding(
                  padding: EdgeInsets.only(
                    left: 12,
                    right: 8,
                    top: 14,
                  ),
                  child: Icon(
                    Icons.notes_rounded,
                    color: AppColors.textSecondary,
                  ),
                ),
                prefixIconConstraints: const BoxConstraints(
                  minWidth: 42,
                  minHeight: 42,
                ),
                filled: true,
                fillColor: AppColors.surface,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(
                    color: AppColors.border,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(
                    color: AppColors.border,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(
                    color: AppColors.primary,
                    width: 1.5,
                  ),
                ),
                contentPadding: const EdgeInsets.fromLTRB(
                  12,
                  14,
                  14,
                  14,
                ),
              ),
              validator: (value) {
                if (value == null || value.trim().isEmpty) {
                  return 'Deskripsi kejadian wajib diisi';
                }

                if (value.trim().length < 5) {
                  return 'Deskripsi terlalu singkat';
                }

                return null;
              },
            ),

            const SizedBox(height: 22),

            // ======================================
            // SECTION: FOTO
            // ======================================
            Row(
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Foto Bukti',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Opsional — foto membantu verifikasi laporan.',
                        style: TextStyle(
                          fontSize: 12,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                if (_photo != null)
                  TextButton.icon(
                    onPressed: _submitting ? null : _removePhoto,
                    icon: const Icon(
                      Icons.delete_outline_rounded,
                      size: 18,
                    ),
                    label: const Text('Hapus'),
                    style: TextButton.styleFrom(
                      foregroundColor: AppColors.danger,
                    ),
                  ),
              ],
            ),

            const SizedBox(height: 12),

            // PHOTO PREVIEW
            GestureDetector(
              onTap: _submitting ? null : _takePhoto,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                height: 190,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: _photo != null
                        ? categoryColor.withValues(alpha: 0.5)
                        : AppColors.border,
                    width: _photo != null ? 1.5 : 1,
                  ),
                ),
                clipBehavior: Clip.antiAlias,
                child: _photo == null
                    ? Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 54,
                            height: 54,
                            decoration: BoxDecoration(
                              color: AppColors.primary.withValues(alpha: 0.08),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.camera_alt_outlined,
                              color: AppColors.primary,
                              size: 26,
                            ),
                          ),
                          const SizedBox(height: 12),
                          const Text(
                            'Ambil Foto Bukti',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            'Ketuk untuk membuka kamera',
                            style: TextStyle(
                              fontSize: 11.5,
                              color: AppColors.textSecondary,
                            ),
                          ),
                        ],
                      )
                    : Stack(
                        fit: StackFit.expand,
                        children: [
                          Image.file(
                            _photo!,
                            fit: BoxFit.cover,
                          ),
                          Positioned(
                            right: 10,
                            bottom: 10,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 7,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.black.withValues(alpha: 0.60),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    Icons.camera_alt_rounded,
                                    color: Colors.white,
                                    size: 15,
                                  ),
                                  SizedBox(width: 5),
                                  Text(
                                    'Ambil Ulang',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
              ),
            ),

            // ======================================
            // LOCATION INFO
            // ======================================
            const SizedBox(height: 22),

            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: AppColors.border,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: AppColors.success.withValues(alpha: 0.10),
                      borderRadius: BorderRadius.circular(11),
                    ),
                    child: const Icon(
                      Icons.location_on_outlined,
                      color: AppColors.success,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Lokasi Kejadian',
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          _gettingLocation
                              ? 'Mengambil lokasi GPS...'
                              : 'Lokasi GPS akan dicatat saat laporan dikirim.',
                          style: const TextStyle(
                            fontSize: 11,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (_gettingLocation)
                    const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                      ),
                    )
                  else
                    const Icon(
                      Icons.check_circle_outline_rounded,
                      color: AppColors.success,
                      size: 20,
                    ),
                ],
              ),
            ),

            // ======================================
            // ERROR
            // ======================================
            if (_error != null) ...[
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.danger.withValues(alpha: 0.07),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: AppColors.danger.withValues(alpha: 0.15),
                  ),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(
                      Icons.error_outline_rounded,
                      color: AppColors.danger,
                      size: 19,
                    ),
                    const SizedBox(width: 9),
                    Expanded(
                      child: Text(
                        _error!,
                        style: const TextStyle(
                          color: AppColors.danger,
                          fontSize: 12,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 24),

            // ======================================
            // SUBMIT BUTTON
            // ======================================
            LoadingButton(
              loading: _submitting,
              label: _gettingLocation ? 'Mengambil Lokasi...' : 'Kirim Laporan',
              color: AppColors.danger,
              onPressed: _submitting ? null : _submit,
            ),

            const SizedBox(height: 12),

            const Center(
              child: Text(
                'Pastikan informasi laporan sudah benar sebelum dikirim.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 11,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
