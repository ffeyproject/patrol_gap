/// Konfigurasi koneksi ke backend Google Apps Script.
///
/// PENTING: Ganti [baseUrl] dengan Web App URL hasil deploy Apps Script kamu.
/// Contoh: https://script.google.com/macros/s/AKfycbxxxxxxxxxxxxxxxxxxx/exec
class ApiConfig {
  static const String baseUrl =
      'https://script.google.com/macros/s/AKfycbzxbTqd1NBk0AwsFB9sDEu9XGUBCgcrrM4N4n6Iv35JjhFZPU5NId4zNIcIe-KEgZsQOQ/exec';

  // Radius default geofencing (meter) - fallback jika diperlukan validasi lokasi
  static const double defaultGeofenceRadius = 50;
}
