import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../models/models.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';
import 'guest_detail_screen.dart';

class TamuScreen extends StatefulWidget {
  final AppUser user;

  const TamuScreen({
    super.key,
    required this.user,
  });

  @override
  State<TamuScreen> createState() => _TamuScreenState();
}

class _TamuScreenState extends State<TamuScreen> {
  List<GuestModel> _guests = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  // ============================================================
  // LOAD DATA
  // ============================================================

  Future<void> _load() async {
    if (mounted) {
      setState(() {
        _loading = true;
      });
    }

    try {
      final res = await ApiService.instance.get(
        'getGuests',
      );

      if (!mounted) return;

      List<GuestModel> guests = [];

      if (res['success'] == true && res['data'] is List) {
        guests = (res['data'] as List)
            .map(
              (e) => GuestModel.fromJson(
                Map<String, dynamic>.from(e as Map),
              ),
            )
            .toList();
      }

      setState(() {
        _loading = false;
        _guests = guests;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _loading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text(
            'Gagal memuat data tamu. Periksa koneksi internet.',
          ),
        ),
      );
    }
  }

  // ============================================================
  // CHECK OUT MANUAL
  // ============================================================

  Future<void> _checkOutById(GuestModel guest) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          titlePadding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
          contentPadding: const EdgeInsets.fromLTRB(20, 8, 20, 10),
          actionsPadding: const EdgeInsets.fromLTRB(16, 4, 16, 14),
          title: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: AppColors.warning.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: const Icon(
                  Icons.logout_rounded,
                  color: AppColors.warning,
                  size: 20,
                ),
              ),
              const SizedBox(width: 11),
              const Expanded(
                child: Text(
                  'Check-Out Tamu',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          content: Text(
            'Apakah tamu "${guest.guestName}" sudah keluar dari area?',
            style: const TextStyle(
              fontSize: 13,
              height: 1.45,
              color: AppColors.textSecondary,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext, false);
              },
              child: const Text('Batal'),
            ),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(dialogContext, true);
              },
              icon: const Icon(
                Icons.check_rounded,
                size: 17,
              ),
              label: const Text('Check-Out'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.success,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        );
      },
    );

    if (confirm != true) return;

    await _doCheckOut({
      'guest_id': guest.guestId,
    });
  }

  // ============================================================
  // PROCESS CHECK OUT
  // ============================================================

  Future<void> _doCheckOut(
    Map<String, dynamic> payload,
  ) async {
    try {
      final res = await ApiService.instance.post(
        'guestCheckOut',
        payload,
      );

      if (!mounted) return;

      if (res['success'] == true) {
        final data = res['data'];

        String guestName = 'Tamu';

        if (data is Map && data['guest_name'] != null) {
          guestName = data['guest_name'].toString();
        }

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            backgroundColor: AppColors.success,
            content: Row(
              children: [
                const Icon(
                  Icons.check_circle_rounded,
                  color: Colors.white,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    '$guestName berhasil check-out',
                  ),
                ),
              ],
            ),
          ),
        );

        await _load();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            backgroundColor: AppColors.danger,
            content: Text(
              res['message']?.toString() ?? 'Gagal melakukan check-out',
            ),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          behavior: SnackBarBehavior.floating,
          backgroundColor: AppColors.danger,
          content: Text(
            'Terjadi kesalahan saat melakukan check-out.',
          ),
        ),
      );
    }
  }

  // ============================================================
  // SCAN QR CHECK OUT
  // ============================================================

  Future<void> _scanCheckOut() async {
    final code = await Navigator.push<String?>(
      context,
      MaterialPageRoute(
        builder: (_) => const _GuestQrScanScreen(),
      ),
    );

    if (!mounted) return;

    if (code == null || code.trim().isEmpty) {
      return;
    }

    await _doCheckOut({
      'qr_guest_code': code.trim(),
    });
  }

  // ============================================================
  // NEW GUEST
  // ============================================================

  void _openNewGuestForm() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      useSafeArea: true,
      builder: (_) {
        return _NewGuestSheet(
          onSaved: _load,
        );
      },
    );
  }

  // ============================================================
  // DETAIL
  // ============================================================

  void _openDetail(GuestModel guest) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => GuestDetailScreen(guest: guest),
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    final active = _guests.where((guest) => !guest.isCheckedOut).toList();

    final history = _guests.where((guest) => guest.isCheckedOut).toList();

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: _buildAppBar(),
      floatingActionButton: _loading
          ? null
          : Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                FloatingActionButton.extended(
                  heroTag: 'scanQrTamu',
                  onPressed: _scanCheckOut,
                  backgroundColor: AppColors.accent,
                  foregroundColor: Colors.white,
                  elevation: 5,
                  icon: const Icon(
                    Icons.qr_code_scanner_rounded,
                  ),
                  label: const Text(
                    'Scan QR Tamu',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                FloatingActionButton.extended(
                  heroTag: 'tamuBaru',
                  onPressed: _openNewGuestForm,
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  elevation: 5,
                  icon: const Icon(
                    Icons.person_add_alt_1_rounded,
                  ),
                  label: const Text(
                    'Tamu Baru',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
      body: RefreshIndicator(
        color: AppColors.primary,
        onRefresh: _load,
        child: _loading
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(
                  16,
                  10,
                  16,
                  150,
                ),
                children: [
                  _buildOverviewCard(
                    activeCount: active.length,
                    historyCount: history.length,
                  ),
                  const SizedBox(height: 16),
                  _buildInstructionCard(),
                  const SizedBox(height: 24),
                  _buildSectionHeader(
                    title: 'Tamu Aktif',
                    subtitle: 'Tamu yang masih berada di area',
                    count: active.length,
                  ),
                  const SizedBox(height: 12),
                  if (active.isEmpty)
                    _buildEmptyActive()
                  else
                    ...active.map(
                      (guest) => _GuestCard(
                        guest: guest,
                        onCheckOut: () => _checkOutById(guest),
                        onTap: () => _openDetail(guest),
                      ),
                    ),
                  const SizedBox(height: 22),
                  _buildSectionHeader(
                    title: 'Riwayat Tamu',
                    subtitle: 'Tamu yang telah meninggalkan area',
                    count: history.length,
                  ),
                  const SizedBox(height: 12),
                  if (history.isEmpty)
                    _buildEmptyHistory()
                  else
                    ...history.map(
                      (guest) => _GuestCard(
                        guest: guest,
                        onCheckOut: null,
                        onTap: () => _openDetail(guest),
                      ),
                    ),
                ],
              ),
      ),
    );
  }

  // ============================================================
  // APP BAR
  // ============================================================

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppColors.bg,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      titleSpacing: 16,
      title: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Buku Tamu Digital',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          SizedBox(height: 2),
          Text(
            'Kelola keluar-masuk tamu',
            style: TextStyle(
              fontSize: 11,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // OVERVIEW
  // ============================================================

  Widget _buildOverviewCard({
    required int activeCount,
    required int historyCount,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            AppColors.accent,
            AppColors.primary,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(21),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withValues(alpha: 0.18),
            blurRadius: 18,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: const Icon(
                  Icons.groups_rounded,
                  color: Colors.white,
                  size: 25,
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'BUKU TAMU',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                      ),
                    ),
                    SizedBox(height: 3),
                    Text(
                      'Monitoring Tamu',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 9,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Row(
                  children: [
                    Icon(
                      Icons.shield_outlined,
                      color: Colors.white,
                      size: 13,
                    ),
                    SizedBox(width: 4),
                    Text(
                      'SECURITY',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 8,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: _OverviewItem(
                  icon: Icons.person_pin_circle_outlined,
                  value: '$activeCount',
                  label: 'Tamu Aktif',
                ),
              ),
              Container(
                width: 1,
                height: 34,
                color: Colors.white.withValues(alpha: 0.15),
              ),
              Expanded(
                child: _OverviewItem(
                  icon: Icons.history_rounded,
                  value: '$historyCount',
                  label: 'Riwayat',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ============================================================
  // INSTRUCTION
  // ============================================================

  Widget _buildInstructionCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.primaryLight,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: AppColors.primary.withValues(alpha: 0.10),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.qr_code_2_rounded,
              color: AppColors.primary,
              size: 20,
            ),
          ),
          const SizedBox(width: 11),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Alur Check-Out',
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    color: AppColors.primaryDark,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Tamu menunjukkan QR Badge yang diberikan saat check-in. Tekan "Scan QR Tamu" untuk melakukan check-out otomatis.',
                  style: TextStyle(
                    fontSize: 11,
                    height: 1.45,
                    color: AppColors.primaryDark,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SECTION HEADER
  // ============================================================

  Widget _buildSectionHeader({
    required String title,
    required String subtitle,
    required int count,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                subtitle,
                style: const TextStyle(
                  fontSize: 10.5,
                  color: AppColors.textSecondary,
                ),
              ),
            ],
          ),
        ),
        Text(
          '$count',
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: AppColors.textSecondary,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // EMPTY ACTIVE
  // ============================================================

  Widget _buildEmptyActive() {
    return Container(
      padding: const EdgeInsets.symmetric(
        vertical: 27,
        horizontal: 20,
      ),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppColors.border,
        ),
      ),
      child: Column(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              color: AppColors.success.withValues(alpha: 0.10),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.verified_user_outlined,
              color: AppColors.success,
              size: 27,
            ),
          ),
          const SizedBox(height: 11),
          const Text(
            'Tidak Ada Tamu Aktif',
            style: TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Saat ini tidak ada tamu yang tercatat berada di dalam area.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 10.5,
              height: 1.4,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // EMPTY HISTORY
  // ============================================================

  Widget _buildEmptyHistory() {
    return Container(
      padding: const EdgeInsets.symmetric(
        vertical: 23,
        horizontal: 20,
      ),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppColors.border,
        ),
      ),
      child: const Row(
        children: [
          Icon(
            Icons.history_rounded,
            color: AppColors.textSecondary,
            size: 25,
          ),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              'Belum ada riwayat tamu.',
              style: TextStyle(
                fontSize: 11.5,
                color: AppColors.textSecondary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// OVERVIEW ITEM
// ============================================================

class _OverviewItem extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;

  const _OverviewItem({
    required this.icon,
    required this.value,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const SizedBox(width: 4),
        Icon(
          icon,
          color: Colors.white70,
          size: 20,
        ),
        const SizedBox(width: 9),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 9.5,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ============================================================
// GUEST CARD
// ============================================================

class _GuestCard extends StatelessWidget {
  final GuestModel guest;
  final VoidCallback? onCheckOut;
  final VoidCallback? onTap;

  const _GuestCard({
    required this.guest,
    required this.onCheckOut,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final active = onCheckOut != null;

    return Container(
      margin: const EdgeInsets.only(bottom: 11),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(
          color: AppColors.border,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(17),
        child: InkWell(
          onTap: onTap,
          child: IntrinsicHeight(
          child: Row(
            children: [
              Container(
                width: 4,
                color: active ? AppColors.accent : AppColors.success,
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: active
                                  ? AppColors.accent.withValues(alpha: 0.10)
                                  : AppColors.success.withValues(alpha: 0.10),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Icon(
                              active
                                  ? Icons.person_pin_rounded
                                  : Icons.person_outline_rounded,
                              color:
                                  active ? AppColors.accent : AppColors.success,
                              size: 23,
                            ),
                          ),
                          const SizedBox(width: 11),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        guest.guestName,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontSize: 13.5,
                                          fontWeight: FontWeight.w700,
                                          color: AppColors.textPrimary,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    StatusPill(
                                      text: active ? 'Di Dalam' : 'Selesai',
                                      color: active
                                          ? AppColors.accent
                                          : AppColors.success,
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 5),
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.business_outlined,
                                      size: 13,
                                      color: AppColors.textSecondary,
                                    ),
                                    const SizedBox(width: 5),
                                    Expanded(
                                      child: Text(
                                        guest.destination,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontSize: 10.5,
                                          color: AppColors.textSecondary,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(11),
                        decoration: BoxDecoration(
                          color: AppColors.bg,
                          borderRadius: BorderRadius.circular(11),
                        ),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                const Icon(
                                  Icons.assignment_outlined,
                                  size: 14,
                                  color: AppColors.textSecondary,
                                ),
                                const SizedBox(width: 7),
                                const Text(
                                  'Keperluan',
                                  style: TextStyle(
                                    fontSize: 9.5,
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    guest.purpose,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.right,
                                    style: const TextStyle(
                                      fontSize: 10.5,
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.textPrimary,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 7),
                            Row(
                              children: [
                                const Icon(
                                  Icons.login_rounded,
                                  size: 14,
                                  color: AppColors.success,
                                ),
                                const SizedBox(width: 7),
                                const Text(
                                  'Check-In',
                                  style: TextStyle(
                                    fontSize: 9.5,
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    guest.checkinTime,
                                    textAlign: TextAlign.right,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      fontSize: 10.5,
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.textPrimary,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 11),
                      Row(
                        children: [
                          const Icon(
                            Icons.badge_outlined,
                            size: 14,
                            color: AppColors.textSecondary,
                          ),
                          const SizedBox(width: 6),
                          const Text(
                            'ID:',
                            style: TextStyle(
                              fontSize: 9.5,
                              color: AppColors.textSecondary,
                            ),
                          ),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              guest.identityNo,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                color: AppColors.textPrimary,
                              ),
                            ),
                          ),
                        ],
                      ),
                      if (active) ...[
                        const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: onCheckOut,
                            icon: const Icon(
                              Icons.logout_rounded,
                              size: 17,
                            ),
                            label: const Text(
                              'Check-Out Manual',
                            ),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: AppColors.danger,
                              side: BorderSide(
                                color: AppColors.danger.withValues(alpha: 0.25),
                              ),
                              minimumSize: const Size.fromHeight(40),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(
                                  11,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      ),
    );
  }
}

// ============================================================
// QR SCANNER
// ============================================================

class _GuestQrScanScreen extends StatefulWidget {
  const _GuestQrScanScreen();

  @override
  State<_GuestQrScanScreen> createState() => _GuestQrScanScreenState();
}

class _GuestQrScanScreenState extends State<_GuestQrScanScreen> {
  final MobileScannerController _controller = MobileScannerController();

  bool _handled = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onDetect(BarcodeCapture capture) {
    if (_handled) return;

    for (final barcode in capture.barcodes) {
      final code = barcode.rawValue?.trim();

      if (code == null || code.isEmpty) {
        continue;
      }

      if (!code.startsWith('GUEST-QR-')) {
        continue;
      }

      _handled = true;
      _controller.stop();

      Navigator.pop(
        context,
        code,
      );

      return;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Scan QR Tamu',
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
            Text(
              'Scan QR untuk check-out',
              style: TextStyle(
                fontSize: 10,
                color: Colors.white60,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Flash',
            onPressed: () {
              _controller.toggleTorch();
            },
            icon: const Icon(
              Icons.flash_on_rounded,
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          MobileScanner(
            controller: _controller,
            onDetect: _onDetect,
          ),

          // Overlay gelap
          IgnorePointer(
            child: Container(
              color: Colors.black.withValues(alpha: 0.38),
            ),
          ),

          // Scanner frame
          Center(
            child: SizedBox(
              width: 275,
              height: 275,
              child: Stack(
                children: [
                  // Kotak tengah transparan
                  Center(
                    child: Container(
                      width: 250,
                      height: 250,
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(22),
                      ),
                    ),
                  ),

                  const _ScannerCorner(
                    alignment: Alignment.topLeft,
                  ),
                  const _ScannerCorner(
                    alignment: Alignment.topRight,
                  ),
                  const _ScannerCorner(
                    alignment: Alignment.bottomLeft,
                  ),
                  const _ScannerCorner(
                    alignment: Alignment.bottomRight,
                  ),
                ],
              ),
            ),
          ),

          Positioned(
            left: 24,
            right: 24,
            bottom: 38,
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 13,
              ),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.68),
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Row(
                children: [
                  Icon(
                    Icons.qr_code_2_rounded,
                    color: Colors.white,
                    size: 21,
                  ),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Arahkan kamera ke QR Badge yang dibawa tamu.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 11.5,
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// SCANNER CORNER
// ============================================================

class _ScannerCorner extends StatelessWidget {
  final Alignment alignment;

  const _ScannerCorner({
    required this.alignment,
  });

  @override
  Widget build(BuildContext context) {
    final isTop = alignment.y < 0;
    final isLeft = alignment.x < 0;

    return Align(
      alignment: alignment,
      child: Container(
        width: 43,
        height: 43,
        decoration: BoxDecoration(
          border: Border(
            top: isTop
                ? const BorderSide(
                    color: AppColors.accent,
                    width: 4,
                  )
                : BorderSide.none,
            bottom: !isTop
                ? const BorderSide(
                    color: AppColors.accent,
                    width: 4,
                  )
                : BorderSide.none,
            left: isLeft
                ? const BorderSide(
                    color: AppColors.accent,
                    width: 4,
                  )
                : BorderSide.none,
            right: !isLeft
                ? const BorderSide(
                    color: AppColors.accent,
                    width: 4,
                  )
                : BorderSide.none,
          ),
        ),
      ),
    );
  }
}

// ============================================================
// NEW GUEST SHEET
// ============================================================

class _NewGuestSheet extends StatefulWidget {
  final VoidCallback onSaved;

  const _NewGuestSheet({
    required this.onSaved,
  });

  @override
  State<_NewGuestSheet> createState() => _NewGuestSheetState();
}

class _NewGuestSheetState extends State<_NewGuestSheet> {
  final _nameCtrl = TextEditingController();
  final _idCtrl = TextEditingController();
  final _destCtrl = TextEditingController();
  final _purposeCtrl = TextEditingController();

  bool _saving = false;
  String? _error;
  Map<String, dynamic>? _savedGuest;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _idCtrl.dispose();
    _destCtrl.dispose();
    _purposeCtrl.dispose();
    super.dispose();
  }

  // ============================================================
  // SAVE GUEST
  // ============================================================

  Future<void> _save() async {
    FocusScope.of(context).unfocus();

    if (_nameCtrl.text.trim().isEmpty ||
        _idCtrl.text.trim().isEmpty ||
        _destCtrl.text.trim().isEmpty ||
        _purposeCtrl.text.trim().isEmpty) {
      setState(() {
        _error = 'Semua field wajib diisi.';
      });
      return;
    }

    setState(() {
      _saving = true;
      _error = null;
    });

    try {
      final res = await ApiService.instance.post(
        'guestCheckIn',
        {
          'guest_name': _nameCtrl.text.trim(),
          'identity_no': _idCtrl.text.trim(),
          'destination': _destCtrl.text.trim(),
          'purpose': _purposeCtrl.text.trim(),
        },
      );

      if (!mounted) return;

      if (res['success'] == true && res['data'] is Map) {
        setState(() {
          _saving = false;
          _savedGuest = Map<String, dynamic>.from(
            res['data'] as Map,
          );
        });

        widget.onSaved();
      } else {
        setState(() {
          _saving = false;
          _error = res['message']?.toString() ?? 'Gagal menyimpan data tamu.';
        });
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _saving = false;
        _error = 'Terjadi kesalahan. Periksa koneksi internet.';
      });
    }
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    final keyboard = MediaQuery.of(context).viewInsets.bottom;

    return Padding(
      padding: EdgeInsets.only(
        bottom: keyboard,
      ),
      child: Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.92,
        ),
        decoration: const BoxDecoration(
          color: AppColors.bg,
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(25),
          ),
        ),
        child: SafeArea(
          top: false,
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(
              20,
              12,
              20,
              22,
            ),
            child: _savedGuest == null ? _buildForm() : _buildQrResult(),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // FORM
  // ============================================================

  Widget _buildForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Center(
          child: Container(
            width: 42,
            height: 4,
            decoration: BoxDecoration(
              color: AppColors.border,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ),
        const SizedBox(height: 17),
        Row(
          children: [
            Container(
              width: 43,
              height: 43,
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: 0.10),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.person_add_alt_1_rounded,
                color: AppColors.primary,
              ),
            ),
            const SizedBox(width: 11),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Check-In Tamu Baru',
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  SizedBox(height: 2),
                  Text(
                    'Lengkapi data sebelum tamu masuk area',
                    style: TextStyle(
                      fontSize: 10.5,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        _buildField(
          controller: _nameCtrl,
          label: 'Nama Tamu',
          hint: 'Masukkan nama lengkap',
          icon: Icons.person_outline_rounded,
          textInputAction: TextInputAction.next,
        ),
        const SizedBox(height: 12),
        _buildField(
          controller: _idCtrl,
          label: 'No. KTP / SIM',
          hint: 'Masukkan nomor identitas',
          icon: Icons.badge_outlined,
          textInputAction: TextInputAction.next,
          keyboardType: TextInputType.number,
        ),
        const SizedBox(height: 12),
        _buildField(
          controller: _destCtrl,
          label: 'Tujuan',
          hint: 'Contoh: Dept. IT / HRD',
          icon: Icons.business_outlined,
          textInputAction: TextInputAction.next,
        ),
        const SizedBox(height: 12),
        _buildField(
          controller: _purposeCtrl,
          label: 'Keperluan',
          hint: 'Masukkan keperluan kunjungan',
          icon: Icons.assignment_outlined,
          textInputAction: TextInputAction.done,
          maxLines: 2,
        ),
        if (_error != null) ...[
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(
              color: AppColors.danger.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(11),
              border: Border.all(
                color: AppColors.danger.withValues(alpha: 0.15),
              ),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(
                  Icons.error_outline_rounded,
                  color: AppColors.danger,
                  size: 18,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _error!,
                    style: const TextStyle(
                      color: AppColors.danger,
                      fontSize: 11,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 19),
        LoadingButton(
          loading: _saving,
          label: 'Simpan & Buat QR Badge',
          onPressed: _save,
        ),
      ],
    );
  }

  // ============================================================
  // FIELD
  // ============================================================

  Widget _buildField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputAction? textInputAction,
    TextInputType? keyboardType,
    int maxLines = 1,
  }) {
    return TextField(
      controller: controller,
      textInputAction: textInputAction,
      keyboardType: keyboardType,
      maxLines: maxLines,
      style: const TextStyle(
        fontSize: 12.5,
        color: AppColors.textPrimary,
      ),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(
          icon,
          size: 19,
        ),
        alignLabelWithHint: maxLines > 1,
      ),
    );
  }

  // ============================================================
  // QR RESULT
  // ============================================================

  Widget _buildQrResult() {
    final qrCode = _savedGuest!['qr_guest_code']?.toString() ?? '';

    final guestName =
        _savedGuest!['guest_name']?.toString() ?? _nameCtrl.text.trim();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Center(
          child: Container(
            width: 42,
            height: 4,
            decoration: BoxDecoration(
              color: AppColors.border,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ),
        const SizedBox(height: 18),
        Center(
          child: Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              color: AppColors.success.withValues(alpha: 0.10),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.check_circle_rounded,
              color: AppColors.success,
              size: 34,
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Center(
          child: Text(
            'Tamu Berhasil Terdaftar',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
        ),
        const SizedBox(height: 4),
        Center(
          child: Text(
            guestName,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: AppColors.primary,
            ),
          ),
        ),
        const SizedBox(height: 7),
        const Text(
          'Berikan QR Badge berikut kepada tamu. QR ini digunakan saat tamu keluar untuk proses check-out.',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 11,
            height: 1.45,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: AppColors.border,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.04),
                blurRadius: 14,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            children: [
              if (qrCode.isNotEmpty)
                QrImageView(
                  data: qrCode,
                  version: QrVersions.auto,
                  size: 195,
                  backgroundColor: Colors.white,
                  eyeStyle: const QrEyeStyle(
                    eyeShape: QrEyeShape.square,
                    color: Colors.black,
                  ),
                  dataModuleStyle: const QrDataModuleStyle(
                    dataModuleShape: QrDataModuleShape.square,
                    color: Colors.black,
                  ),
                )
              else
                const SizedBox(
                  height: 195,
                  child: Center(
                    child: Text(
                      'QR tidak tersedia',
                      style: TextStyle(
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ),
                ),
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: AppColors.bg,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  children: [
                    const Text(
                      'KODE QR TAMU',
                      style: TextStyle(
                        fontSize: 8,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      qrCode.isEmpty ? '-' : qrCode,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 17),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.accent.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                Icons.info_outline_rounded,
                size: 18,
                color: AppColors.accent,
              ),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Minta tamu menyimpan QR ini. Saat keluar, scan QR melalui menu "Scan QR Tamu".',
                  style: TextStyle(
                    fontSize: 10.5,
                    height: 1.4,
                    color: AppColors.textPrimary,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 17),
        ElevatedButton.icon(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.check_rounded,
            size: 18,
          ),
          label: const Text(
            'Selesai',
            style: TextStyle(
              fontWeight: FontWeight.w700,
            ),
          ),
          style: ElevatedButton.styleFrom(
            minimumSize: const Size.fromHeight(46),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
      ],
    );
  }
}
