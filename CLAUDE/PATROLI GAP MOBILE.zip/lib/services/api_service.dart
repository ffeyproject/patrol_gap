import 'dart:convert';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:http/http.dart' as http;
import '../config/api_config.dart';

/// Service pusat untuk komunikasi dengan backend Google Apps Script.
///
/// CATATAN PENTING SOAL WEB vs MOBILE:
/// Di Android/iOS, HTTP client tidak menerapkan aturan CORS (itu aturan
/// khusus browser), jadi request apapun ke Apps Script akan tembus asal
/// URL & datanya benar. Begitu dijalankan di Chrome (Flutter Web), browser
/// menerapkan CORS: setiap request lintas origin dengan header
/// `Content-Type: application/json` dianggap "non-simple request" dan
/// browser WAJIB mengirim preflight (OPTIONS) dulu. Apps Script Web App
/// tidak mengimplementasikan `doOptions`, jadi preflight itu selalu gagal
/// (tidak ada header `Access-Control-Allow-Origin`) → browser blokir
/// requestnya sebelum sempat terkirim. Itu sumber error
/// "blocked by CORS policy" / "net::ERR_FAILED 302" yang muncul di console.
///
/// FIX: khusus di Web, body tetap dikirim sebagai JSON string, tapi header
/// Content-Type diganti ke `text/plain;charset=utf-8`. Itu termasuk
/// "simple request" di spesifikasi CORS sehingga browser TIDAK mengirim
/// preflight sama sekali. Apps Script tetap bisa mem-parse isinya sebagai
/// JSON di sisi server lewat `e.postData.contents` — Content-Type header
/// tidak mempengaruhi cara Apps Script membaca body mentah itu. Redirect
/// internal Apps Script (302 → script.googleusercontent.com) juga
/// dibiarkan diikuti otomatis oleh browser (tidak coba di-manual-redirect
/// lagi di Web), karena browser tidak mengizinkan JS mengatur ulang
/// redirect lintas-origin itu sendiri.
class ApiService {
  ApiService._();
  static final ApiService instance = ApiService._();

  final http.Client _client = http.Client();

  /// GET request - dipakai untuk action pengambilan data (list, summary, dll)
  Future<Map<String, dynamic>> get(String action,
      [Map<String, String>? params]) async {
    final query = {'action': action, ...?params};
    final uri =
        Uri.parse(ApiConfig.baseUrl).replace(queryParameters: query);

    try {
      final res = await _client.get(uri);
      return _parse(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Gagal terhubung ke server: $e'};
    }
  }

  /// POST request - dipakai untuk action penulisan data (checkin, scan, dll)
  Future<Map<String, dynamic>> post(
      String action, Map<String, dynamic> body) async {
    final payload = {'action': action, ...body};
    final jsonBody = jsonEncode(payload);

    try {
      final result = kIsWeb
          ? await _postWeb(jsonBody)
          : await _postMobileWithManualRedirect(jsonBody);
      return _parse(result);
    } catch (e) {
      return {'success': false, 'message': 'Gagal mengirim data: $e'};
    }
  }

  /// Di Web: Content-Type harus text/plain supaya browser tidak mengirim
  /// preflight OPTIONS (lihat penjelasan di atas kelas). Redirect Apps
  /// Script diikuti otomatis oleh browser sendiri.
  Future<String> _postWeb(String jsonBody) async {
    final res = await _client.post(
      Uri.parse(ApiConfig.baseUrl),
      headers: {'Content-Type': 'text/plain;charset=utf-8'},
      body: jsonBody,
    );
    return res.body;
  }

  /// Di Android/iOS: dart:io tidak dipakai lagi (supaya kompatibel dengan
  /// Web di file yang sama), tapi CORS tidak berlaku di sini sehingga bisa
  /// pakai package:http biasa dengan redirect manual seperti semula.
  Future<String> _postMobileWithManualRedirect(String jsonBody) async {
    var request = http.Request('POST', Uri.parse(ApiConfig.baseUrl))
      ..followRedirects = false
      ..headers['Content-Type'] = 'application/json'
      ..body = jsonBody;

    var streamed = await _client.send(request);

    int redirectCount = 0;
    while (_isRedirect(streamed.statusCode) && redirectCount < 5) {
      final location = streamed.headers['location'];
      if (location == null) break;
      final nextRequest = http.Request('GET', Uri.parse(location))
        ..followRedirects = false;
      streamed = await _client.send(nextRequest);
      redirectCount++;
    }

    final response = await http.Response.fromStream(streamed);
    return response.body;
  }

  bool _isRedirect(int statusCode) =>
      statusCode == 301 || statusCode == 302 || statusCode == 303;

  Map<String, dynamic> _parse(String body) {
    try {
      final decoded = jsonDecode(body);
      if (decoded is Map<String, dynamic>) return decoded;
      return {'success': false, 'message': 'Format response tidak sesuai'};
    } catch (e) {
      return {
        'success': false,
        'message': 'Gagal membaca response server (bukan JSON valid)'
      };
    }
  }
}
