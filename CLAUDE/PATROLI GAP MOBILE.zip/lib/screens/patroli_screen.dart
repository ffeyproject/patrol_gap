import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../services/offline_service.dart';
import '../theme/app_theme.dart';
import 'qr_scan_screen.dart';

class PatroliScreen extends StatefulWidget {
  final AppUser user;

  const PatroliScreen({
    super.key,
    required this.user,
  });

  @override
  State<PatroliScreen> createState() => _PatroliScreenState();
}

class _PatroliScreenState extends State<PatroliScreen> {
  List<CheckpointModel> _checkpoints = [];
  Set<String> _scannedToday = {};

  bool _loading = true;
  bool _syncing = false;
  int _pendingSync = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) {
      setState(() {
        _loading = true;
      });
    }

    try {
      final today = DateTime.now().toIso8601String().substring(0, 10);

      final cpRes = await ApiService.instance.get(
        'getCheckpoints',
        {
          'site_id': widget.user.assignedSiteId,
        },
      );

      final logRes = await ApiService.instance.get(
        'getPatrolLogs',
        {
          'user_id': widget.user.userId,
          'date': today,
        },
      );

      final pending = await OfflineService.instance.pendingCount();

      if (!mounted) return;

      List<CheckpointModel> checkpoints = [];
      Set<String> scannedToday = {};

      // ================================
      // CHECKPOINT
      // ================================
      if (cpRes['success'] == true && cpRes['data'] is List) {
        final data = cpRes['data'] as List;

        checkpoints = data
            .map(
              (e) => CheckpointModel.fromJson(
                Map<String, dynamic>.from(e as Map),
              ),
            )
            .toList();
      }

      // ================================
      // PATROL LOG
      // ================================
      if (logRes['success'] == true && logRes['data'] is List) {
        final data = logRes['data'] as List;

        scannedToday = data
            .map(
              (e) => e['checkpoint_id']?.toString() ?? '',
            )
            .where(
              (id) => id.isNotEmpty,
            )
            .toSet();
      }

      setState(() {
        _loading = false;
        _pendingSync = pending;
        _checkpoints = checkpoints;
        _scannedToday = scannedToday;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _loading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text(
            'Gagal memuat data patroli: $e',
          ),
        ),
      );
    }
  }

  Future<void> _sync() async {
    if (_syncing) return;

    setState(() {
      _syncing = true;
    });

    try {
      final count = await OfflineService.instance.syncAll();

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text(
            count > 0
                ? '$count data patroli berhasil disinkronkan'
                : 'Belum ada data untuk disinkronkan',
          ),
        ),
      );

      await _load();
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text(
            'Sinkronisasi gagal. Silakan coba lagi.',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _syncing = false;
        });
      }
    }
  }

  Future<void> _scanQr() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => QrScanScreen(
          user: widget.user,
        ),
      ),
    );

    if (result == true && mounted) {
      await _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final done = _checkpoints
        .where(
          (checkpoint) => _scannedToday.contains(checkpoint.checkpointId),
        )
        .length;

    final total = _checkpoints.length;

    final progress = total == 0 ? 0.0 : done / total;

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: _buildAppBar(),
      floatingActionButton: _loading
          ? null
          : FloatingActionButton.extended(
              onPressed: _scanQr,
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              elevation: 5,
              icon: const Icon(
                Icons.qr_code_scanner_rounded,
              ),
              label: const Text(
                'Scan QR',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
      body: RefreshIndicator(
        color: AppColors.primary,
        onRefresh: _load,
        child: _loading
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(
                  16,
                  10,
                  16,
                  100,
                ),
                children: [
                  _buildSiteHeader(),
                  const SizedBox(height: 14),
                  _buildProgressCard(
                    done: done,
                    total: total,
                    progress: progress,
                  ),
                  const SizedBox(height: 24),
                  _buildSectionHeader(
                    title: 'Checkpoint Patroli',
                    subtitle: total == 0
                        ? 'Belum ada checkpoint'
                        : '$done dari $total checkpoint selesai',
                  ),
                  const SizedBox(height: 12),
                  if (_checkpoints.isEmpty)
                    _buildEmptyState()
                  else
                    ..._checkpoints.asMap().entries.map(
                      (entry) {
                        final index = entry.key;
                        final checkpoint = entry.value;

                        final scanned = _scannedToday.contains(
                          checkpoint.checkpointId,
                        );

                        return _CheckpointCard(
                          number: index + 1,
                          checkpoint: checkpoint,
                          scanned: scanned,
                        );
                      },
                    ),
                  if (_pendingSync > 0) ...[
                    const SizedBox(height: 14),
                    _buildSyncCard(),
                  ],
                ],
              ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppColors.bg,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      titleSpacing: 16,
      title: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Patroli',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          SizedBox(height: 2),
          Text(
            'Checkpoint keamanan',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w400,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
      actions: [
        if (_pendingSync > 0)
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: _SyncButton(
              count: _pendingSync,
              loading: _syncing,
              onPressed: _sync,
            ),
          ),
      ],
    );
  }

  Widget _buildSiteHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 15,
        vertical: 13,
      ),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: AppColors.border,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(11),
            ),
            child: const Icon(
              Icons.location_on_rounded,
              color: AppColors.primary,
              size: 20,
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Lokasi Patroli',
                  style: TextStyle(
                    fontSize: 10.5,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Site ${widget.user.assignedSiteId}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 9,
              vertical: 6,
            ),
            decoration: BoxDecoration(
              color: AppColors.success.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(
                    color: AppColors.success,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 5),
                const Text(
                  'AKTIF',
                  style: TextStyle(
                    color: AppColors.success,
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressCard({
    required int done,
    required int total,
    required double progress,
  }) {
    final percentage = (progress * 100).round();

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            AppColors.primary,
            AppColors.primaryDark,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(21),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withValues(alpha: 0.18),
            blurRadius: 18,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'PROGRES PATROLI',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.7,
                      ),
                    ),
                    const SizedBox(height: 7),
                    Text(
                      '$done / $total',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 30,
                        fontWeight: FontWeight.w800,
                        height: 1,
                      ),
                    ),
                    const SizedBox(height: 5),
                    const Text(
                      'Checkpoint selesai hari ini',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 11.5,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                width: 64,
                height: 64,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    CircularProgressIndicator(
                      value: progress,
                      color: Colors.white,
                      backgroundColor: Colors.white24,
                      strokeWidth: 5,
                    ),
                    Text(
                      '$percentage%',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 7,
              backgroundColor: Colors.white24,
              valueColor: const AlwaysStoppedAnimation<Color>(
                Colors.white,
              ),
            ),
          ),
          const SizedBox(height: 13),
          Row(
            children: [
              const Icon(
                Icons.access_time_rounded,
                color: Colors.white70,
                size: 15,
              ),
              const SizedBox(width: 5),
              const Text(
                'Status patroli hari ini',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 10.5,
                ),
              ),
              const Spacer(),
              Text(
                total > 0 && done == total
                    ? 'Patroli selesai'
                    : 'Sedang berjalan',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader({
    required String title,
    required String subtitle,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                subtitle,
                style: const TextStyle(
                  fontSize: 11,
                  color: AppColors.textSecondary,
                ),
              ),
            ],
          ),
        ),
        if (_checkpoints.isNotEmpty)
          Text(
            '${_checkpoints.length} titik',
            style: const TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w600,
              color: AppColors.textSecondary,
            ),
          ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 24,
        vertical: 40,
      ),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: AppColors.border,
        ),
      ),
      child: Column(
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.08),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.location_off_outlined,
              color: AppColors.primary,
              size: 27,
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            'Belum Ada Checkpoint',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            'Belum terdapat checkpoint patroli yang terdaftar untuk site ${widget.user.assignedSiteId}.',
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 11.5,
              color: AppColors.textSecondary,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSyncCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.warning.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: AppColors.warning.withValues(alpha: 0.25),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: AppColors.warning.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(11),
            ),
            child: const Icon(
              Icons.cloud_upload_outlined,
              color: AppColors.warning,
              size: 20,
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$_pendingSync data menunggu sinkronisasi',
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 3),
                const Text(
                  'Data akan dikirim ke server saat tersambung.',
                  style: TextStyle(
                    fontSize: 10.5,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          TextButton(
            onPressed: _syncing ? null : _sync,
            child: Text(
              _syncing ? '...' : 'Sync',
              style: const TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// CHECKPOINT CARD
// ============================================================

class _CheckpointCard extends StatelessWidget {
  final int number;
  final CheckpointModel checkpoint;
  final bool scanned;

  const _CheckpointCard({
    required this.number,
    required this.checkpoint,
    required this.scanned,
  });

  @override
  Widget build(BuildContext context) {
    final color = scanned ? AppColors.success : AppColors.warning;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(
          color:
              scanned ? AppColors.success.withValues(alpha: 0.22) : AppColors.border,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            // Nomor checkpoint
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.10),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: scanned
                    ? const Icon(
                        Icons.check_rounded,
                        color: AppColors.success,
                        size: 21,
                      )
                    : Text(
                        '$number',
                        style: TextStyle(
                          color: color,
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
              ),
            ),

            const SizedBox(width: 12),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    checkpoint.checkpointName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Row(
                    children: [
                      const Icon(
                        Icons.qr_code_2_rounded,
                        size: 14,
                        color: AppColors.textSecondary,
                      ),
                      const SizedBox(width: 5),
                      Expanded(
                        child: Text(
                          checkpoint.qrCodeVal,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 10.5,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(width: 8),

            _StatusBadge(
              text: scanned ? 'Selesai' : 'Belum',
              color: color,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// STATUS BADGE
// ============================================================

class _StatusBadge extends StatelessWidget {
  final String text;
  final Color color;

  const _StatusBadge({
    required this.text,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 9,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontSize: 9.5,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

// ============================================================
// SYNC BUTTON
// ============================================================

class _SyncButton extends StatelessWidget {
  final int count;
  final bool loading;
  final VoidCallback onPressed;

  const _SyncButton({
    required this.count,
    required this.loading,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.warning.withValues(alpha: 0.10),
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: loading ? null : onPressed,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 10,
            vertical: 8,
          ),
          child: Row(
            children: [
              Icon(
                loading ? Icons.sync_rounded : Icons.cloud_upload_outlined,
                color: AppColors.warning,
                size: 19,
              ),
              const SizedBox(width: 6),
              Text(
                '$count',
                style: const TextStyle(
                  color: AppColors.warning,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
