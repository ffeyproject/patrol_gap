class AppUser {
  final String userId;
  final String username;
  final String fullName;
  final String role;
  final String assignedSiteId;
  final String status;

  AppUser({
    required this.userId,
    required this.username,
    required this.fullName,
    required this.role,
    required this.assignedSiteId,
    required this.status,
  });

  factory AppUser.fromJson(Map<String, dynamic> json) => AppUser(
        userId: json['user_id']?.toString() ?? '',
        username: json['username']?.toString() ?? '',
        fullName: json['full_name']?.toString() ?? '',
        role: json['role']?.toString() ?? '',
        assignedSiteId: json['assigned_site_id']?.toString() ?? '',
        status: json['status']?.toString() ?? '',
      );

  Map<String, dynamic> toJson() => {
        'user_id': userId,
        'username': username,
        'full_name': fullName,
        'role': role,
        'assigned_site_id': assignedSiteId,
        'status': status,
      };

  bool get isSatpam => role == 'Satpam';
  bool get isDanru => role == 'Danru';
  bool get isSupervisor => role == 'Supervisor';
  bool get isAdmin => role == 'Super Admin';
  bool get canSupervise => isDanru || isSupervisor || isAdmin;
}

class SiteModel {
  final String siteId;
  final String siteName;
  final String address;
  final double latitude;
  final double longitude;

  SiteModel({
    required this.siteId,
    required this.siteName,
    required this.address,
    required this.latitude,
    required this.longitude,
  });

  factory SiteModel.fromJson(Map<String, dynamic> json) => SiteModel(
        siteId: json['site_id']?.toString() ?? '',
        siteName: json['site_name']?.toString() ?? '',
        address: json['address']?.toString() ?? '',
        latitude: double.tryParse(json['latitude'].toString()) ?? 0,
        longitude: double.tryParse(json['longitude'].toString()) ?? 0,
      );
}

class CheckpointModel {
  final String checkpointId;
  final String siteId;
  final String checkpointName;
  final String qrCodeVal;
  final double targetLat;
  final double targetLong;

  CheckpointModel({
    required this.checkpointId,
    required this.siteId,
    required this.checkpointName,
    required this.qrCodeVal,
    required this.targetLat,
    required this.targetLong,
  });

  factory CheckpointModel.fromJson(Map<String, dynamic> json) =>
      CheckpointModel(
        checkpointId: json['checkpoint_id']?.toString() ?? '',
        siteId: json['site_id']?.toString() ?? '',
        checkpointName: json['checkpoint_name']?.toString() ?? '',
        qrCodeVal: json['qr_code_val']?.toString() ?? '',
        targetLat: double.tryParse(json['target_lat'].toString()) ?? 0,
        targetLong: double.tryParse(json['target_long'].toString()) ?? 0,
      );
}

class PatrolLogModel {
  final String logId;
  final String timestamp;
  final String userId;
  final String checkpointId;
  final String notes;
  final bool pendingSync;

  PatrolLogModel({
    required this.logId,
    required this.timestamp,
    required this.userId,
    required this.checkpointId,
    required this.notes,
    this.pendingSync = false,
  });

  factory PatrolLogModel.fromJson(Map<String, dynamic> json) => PatrolLogModel(
        logId: json['log_id']?.toString() ?? '',
        timestamp: json['timestamp']?.toString() ?? '',
        userId: json['user_id']?.toString() ?? '',
        checkpointId: json['checkpoint_id']?.toString() ?? '',
        notes: json['notes']?.toString() ?? '',
      );
}

class IncidentModel {
  final String incidentId;
  final String timestamp;
  final String userId;
  final String title;
  final String description;
  final String photoUrl;

  IncidentModel({
    required this.incidentId,
    required this.timestamp,
    required this.userId,
    required this.title,
    required this.description,
    required this.photoUrl,
  });

  factory IncidentModel.fromJson(Map<String, dynamic> json) => IncidentModel(
        incidentId: json['incident_id']?.toString() ?? '',
        timestamp: json['timestamp']?.toString() ?? '',
        userId: json['user_id']?.toString() ?? '',
        title: json['title']?.toString() ?? '',
        description: json['description']?.toString() ?? '',
        photoUrl: json['photo_url']?.toString() ?? '',
      );
}

class GuestModel {
  final String guestId;
  final String checkinTime;
  final String checkoutTime;
  final String guestName;
  final String identityNo;
  final String destination;
  final String purpose;
  final String qrGuestCode;

  GuestModel({
    required this.guestId,
    required this.checkinTime,
    required this.checkoutTime,
    required this.guestName,
    required this.identityNo,
    required this.destination,
    required this.purpose,
    required this.qrGuestCode,
  });

  factory GuestModel.fromJson(Map<String, dynamic> json) => GuestModel(
        guestId: json['guest_id']?.toString() ?? '',
        checkinTime: json['checkin_time']?.toString() ?? '',
        checkoutTime: json['checkout_time']?.toString() ?? '',
        guestName: json['guest_name']?.toString() ?? '',
        identityNo: json['identity_no']?.toString() ?? '',
        destination: json['destination']?.toString() ?? '',
        purpose: json['purpose']?.toString() ?? '',
        qrGuestCode: json['qr_guest_code']?.toString() ?? '',
      );

  bool get isCheckedOut => checkoutTime.isNotEmpty;
}
