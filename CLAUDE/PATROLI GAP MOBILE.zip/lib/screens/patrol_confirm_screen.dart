import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../models/models.dart';
import '../services/api_service.dart';
import '../services/location_service.dart';
import '../services/offline_service.dart';
import '../services/watermark_service.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';

class PatrolConfirmScreen extends StatefulWidget {
  final AppUser user;
  final CheckpointModel checkpoint;

  const PatrolConfirmScreen({
    super.key,
    required this.user,
    required this.checkpoint,
  });

  @override
  State<PatrolConfirmScreen> createState() => _PatrolConfirmScreenState();
}

class _PatrolConfirmScreenState extends State<PatrolConfirmScreen> {
  final ImagePicker _picker = ImagePicker();
  final TextEditingController _notesCtrl = TextEditingController();

  File? _photo;

  String _status = 'Aman';

  bool _submitting = false;
  bool _processingPhoto = false;
  String? _error;

  final List<String> _statusOptions = [
    'Aman',
    'Lampu Mati',
    'Pintu Tidak Terkunci',
    'Mencurigakan',
    'Lainnya',
  ];

  @override
  void dispose() {
    _notesCtrl.dispose();
    super.dispose();
  }

  // ============================================================
  // AMBIL FOTO
  // ============================================================

  Future<void> _takePhoto() async {
    try {
      final XFile? xfile = await _picker.pickImage(
        source: ImageSource.camera,
        preferredCameraDevice: CameraDevice.front,
        imageQuality: 70,
        maxWidth: 1600,
        maxHeight: 1600,
      );

      if (xfile == null || !mounted) return;

      setState(() {
        _processingPhoto = true;
        _error = null;
      });

      // ----------------------------------------------------------
      // Ambil posisi GPS saat foto diambil, lalu bubuhkan watermark
      // (nama, hari/tanggal, lokasi, titik koordinat) langsung ke
      // dalam foto sebelum ditampilkan/disimpan.
      // ----------------------------------------------------------

      final pos = await LocationService.instance.getCurrentPosition();

      final watermarked = await WatermarkService.instance.applyWatermark(
        photo: File(xfile.path),
        fullName: widget.user.fullName,
        position: pos,
        checkpointName: widget.checkpoint.checkpointName,
      );

      if (!mounted) return;

      setState(() {
        _photo = watermarked;
        _processingPhoto = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _processingPhoto = false;
        _error = 'Gagal mengambil foto/lokasi: ${_cleanError(e)}';
      });
    }
  }

  // ============================================================
  // SUBMIT PATROLI
  // ============================================================

  Future<void> _submit() async {
    if (_photo == null) {
      setState(() {
        _error = 'Foto selfie wajib dilampirkan.';
      });
      return;
    }

    setState(() {
      _submitting = true;
      _error = null;
    });

    try {
      // ----------------------------------------------------------
      // Ambil lokasi
      // ----------------------------------------------------------

      final pos = await LocationService.instance.getCurrentPosition();

      // ----------------------------------------------------------
      // Konversi foto ke Base64
      // ----------------------------------------------------------

      final bytes = await _photo!.readAsBytes();

      final photoBase64 = 'data:image/jpeg;base64,${base64Encode(bytes)}';

      // ----------------------------------------------------------
      // Gabungkan status + catatan
      // ----------------------------------------------------------

      final noteText = _notesCtrl.text.trim();

      final notes = noteText.isEmpty ? _status : '$_status - $noteText';

      // ----------------------------------------------------------
      // Payload
      // ----------------------------------------------------------

      final payload = <String, dynamic>{
        'user_id': widget.user.userId,
        'checkpoint_id': widget.checkpoint.checkpointId,
        'scan_lat': pos.latitude,
        'scan_long': pos.longitude,
        'photo_base64': photoBase64,
        'notes': notes,
      };

      // ----------------------------------------------------------
      // Cek koneksi
      // ----------------------------------------------------------

      final hasConnection = await OfflineService.instance.hasConnection();

      if (!hasConnection) {
        await OfflineService.instance.enqueue(
          'patrolScan',
          payload,
        );

        if (!mounted) return;

        _showResultAndPop(
          message:
              'Tidak ada koneksi internet.\n\nData patroli telah disimpan di perangkat dan akan disinkronkan ketika koneksi tersedia.',
          isSuccess: true,
          offline: true,
        );

        return;
      }

      // ----------------------------------------------------------
      // Kirim ke server
      // ----------------------------------------------------------

      final res = await ApiService.instance.post(
        'patrolScan',
        payload,
      );

      if (!mounted) return;

      if (res['success'] == true) {
        _showResultAndPop(
          message: 'Checkpoint berhasil dicatat ke sistem.',
          isSuccess: true,
        );
      } else {
        // Server merespons tetapi menolak request.
        // Jangan masukkan ke offline queue.
        setState(() {
          _submitting = false;
          _error = res['message']?.toString() ??
              'Checkpoint ditolak server. Silakan periksa lokasi dan coba kembali.';
        });
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _submitting = false;
        _error = _cleanError(e);
      });
    }
  }

  String _cleanError(Object error) {
    return error.toString().replaceFirst('Exception: ', '').trim();
  }

  // ============================================================
  // DIALOG HASIL
  // ============================================================

  void _showResultAndPop({
    required String message,
    required bool isSuccess,
    bool offline = false,
  }) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
          ),
          contentPadding: const EdgeInsets.fromLTRB(
            24,
            28,
            24,
            12,
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 68,
                height: 68,
                decoration: BoxDecoration(
                  color: (isSuccess ? AppColors.success : AppColors.danger)
                      .withValues(alpha: 0.10),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  isSuccess ? Icons.check_circle_rounded : Icons.error_rounded,
                  color: isSuccess ? AppColors.success : AppColors.danger,
                  size: 38,
                ),
              ),
              const SizedBox(height: 18),
              Text(
                isSuccess ? 'Patroli Berhasil' : 'Patroli Gagal',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 13,
                  height: 1.5,
                  color: AppColors.textSecondary,
                ),
              ),
              if (offline) ...[
                const SizedBox(height: 14),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.warning.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Row(
                    children: [
                      Icon(
                        Icons.cloud_off_rounded,
                        color: AppColors.warning,
                        size: 19,
                      ),
                      SizedBox(width: 9),
                      Expanded(
                        child: Text(
                          'Data akan dikirim otomatis saat internet tersedia.',
                          style: TextStyle(
                            fontSize: 11.5,
                            color: AppColors.warning,
                            height: 1.4,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
          actionsPadding: const EdgeInsets.fromLTRB(
            16,
            4,
            16,
            14,
          ),
          actions: [
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () {
                  Navigator.pop(dialogContext);
                  Navigator.pop(context, true);
                },
                style: FilledButton.styleFrom(
                  backgroundColor:
                      isSuccess ? AppColors.primary : AppColors.danger,
                  minimumSize: const Size.fromHeight(46),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text(
                  'Kembali ke Patroli',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // ============================================================
  // HEADER CHECKPOINT
  // ============================================================

  Widget _buildCheckpointCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            AppColors.primary,
            AppColors.primaryDark,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withValues(alpha: 0.18),
            blurRadius: 18,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(15),
            ),
            child: const Icon(
              Icons.location_on_rounded,
              color: Colors.white,
              size: 27,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'CHECKPOINT',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.1,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.checkpoint.checkpointName,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.checkpoint.qrCodeVal,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 11.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // FOTO
  // ============================================================

  Widget _buildPhotoSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionTitle(
          icon: Icons.camera_front_rounded,
          title: 'Foto Selfie Petugas',
          required: true,
        ),
        const SizedBox(height: 9),
        GestureDetector(
          onTap: (_submitting || _processingPhoto) ? null : _takePhoto,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            height: 200,
            width: double.infinity,
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: _photo == null
                    ? AppColors.border
                    : AppColors.success.withValues(alpha: 0.45),
                width: _photo == null ? 1 : 1.5,
              ),
            ),
            child: _processingPhoto
                ? _buildPhotoProcessing()
                : (_photo == null
                    ? _buildPhotoPlaceholder()
                    : _buildPhotoPreview()),
          ),
        ),
        if (_photo != null) ...[
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(
                Icons.check_circle_rounded,
                color: AppColors.success,
                size: 16,
              ),
              const SizedBox(width: 6),
              const Expanded(
                child: Text(
                  'Foto berhasil dipilih',
                  style: TextStyle(
                    fontSize: 11.5,
                    color: AppColors.success,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              TextButton(
                onPressed: (_submitting || _processingPhoto) ? null : _takePhoto,
                child: const Text('Ambil Ulang'),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Widget _buildPhotoPlaceholder() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 58,
          height: 58,
          decoration: BoxDecoration(
            color: AppColors.primary.withValues(alpha: 0.08),
            shape: BoxShape.circle,
          ),
          child: const Icon(
            Icons.camera_front_rounded,
            color: AppColors.primary,
            size: 27,
          ),
        ),
        const SizedBox(height: 12),
        const Text(
          'Ambil Foto Selfie',
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 4),
        const Text(
          'Selfie wajib sebagai bukti kehadiran patroli',
          style: TextStyle(
            fontSize: 11.5,
            color: AppColors.textSecondary,
          ),
        ),
      ],
    );
  }

  Widget _buildPhotoProcessing() {
    return const Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(
          width: 26,
          height: 26,
          child: CircularProgressIndicator(strokeWidth: 2.6),
        ),
        SizedBox(height: 12),
        Text(
          'Menambahkan watermark...',
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: AppColors.textSecondary,
          ),
        ),
      ],
    );
  }

  Widget _buildPhotoPreview() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(17),
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.file(
            _photo!,
            fit: BoxFit.cover,
          ),
          Positioned(
            right: 10,
            top: 10,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.55),
                shape: BoxShape.circle,
              ),
              child: IconButton(
                onPressed: (_submitting || _processingPhoto) ? null : _takePhoto,
                icon: const Icon(
                  Icons.refresh_rounded,
                  color: Colors.white,
                  size: 20,
                ),
                tooltip: 'Ambil ulang',
              ),
            ),
          ),
          Positioned(
            left: 10,
            bottom: 10,
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 6,
              ),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.60),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.check_circle_rounded,
                    color: Colors.white,
                    size: 15,
                  ),
                  SizedBox(width: 5),
                  Text(
                    'Foto siap',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // STATUS KEAMANAN
  // ============================================================

  Widget _buildStatusSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionTitle(
          icon: Icons.security_rounded,
          title: 'Status Keamanan',
          required: true,
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: _statusOptions.map((status) {
            final selected = _status == status;

            return ChoiceChip(
              label: Text(status),
              selected: selected,
              onSelected: _submitting
                  ? null
                  : (_) {
                      setState(() {
                        _status = status;
                        _error = null;
                      });
                    },
              selectedColor: AppColors.primary,
              backgroundColor: AppColors.surface,
              side: BorderSide(
                color: selected ? AppColors.primary : AppColors.border,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              labelStyle: TextStyle(
                color: selected ? Colors.white : AppColors.textPrimary,
                fontSize: 12,
                fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
              ),
              padding: const EdgeInsets.symmetric(
                horizontal: 4,
                vertical: 2,
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  // ============================================================
  // CATATAN
  // ============================================================

  Widget _buildNotesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionTitle(
          icon: Icons.notes_rounded,
          title: 'Catatan Tambahan',
          required: false,
        ),
        const SizedBox(height: 9),
        TextField(
          controller: _notesCtrl,
          enabled: !_submitting,
          maxLines: 4,
          textInputAction: TextInputAction.newline,
          decoration: const InputDecoration(
            hintText: 'Contoh: Lampu koridor lantai 2 mati...',
            alignLabelWithHint: true,
            prefixIcon: Padding(
              padding: EdgeInsets.only(bottom: 60),
              child: Icon(Icons.edit_note_rounded),
            ),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // ERROR
  // ============================================================

  Widget _buildError() {
    if (_error == null) {
      return const SizedBox.shrink();
    }

    return Container(
      margin: const EdgeInsets.only(top: 16),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: AppColors.danger.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: AppColors.danger.withValues(alpha: 0.15),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(
            Icons.error_outline_rounded,
            color: AppColors.danger,
            size: 20,
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              _error!,
              style: const TextStyle(
                color: AppColors.danger,
                fontSize: 12,
                height: 1.45,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SECTION TITLE
  // ============================================================

  Widget _sectionTitle({
    required IconData icon,
    required String title,
    required bool required,
  }) {
    return Row(
      children: [
        Icon(
          icon,
          size: 18,
          color: AppColors.primary,
        ),
        const SizedBox(width: 7),
        Text(
          title,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
        if (required) ...[
          const SizedBox(width: 4),
          const Text(
            '*',
            style: TextStyle(
              color: AppColors.danger,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ],
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('Konfirmasi Patroli'),
        centerTitle: false,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            16,
            16,
            16,
            32,
          ),
          children: [
            // Checkpoint
            _buildCheckpointCard(),

            const SizedBox(height: 24),

            // Foto
            _buildPhotoSection(),

            const SizedBox(height: 24),

            // Status
            _buildStatusSection(),

            const SizedBox(height: 22),

            // Catatan
            _buildNotesSection(),

            // Error
            _buildError(),

            const SizedBox(height: 26),

            // Tombol simpan
            LoadingButton(
              loading: _submitting,
              label: 'Simpan Hasil Patroli',
              onPressed: _processingPhoto ? null : _submit,
            ),

            const SizedBox(height: 10),

            const Center(
              child: Text(
                'Lokasi GPS akan dicatat bersama hasil patroli',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 10.5,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
