import 'package:flutter/material.dart';

import '../models/models.dart';
import '../theme/app_theme.dart';
import 'beranda_screen.dart';
import 'patroli_screen.dart';
import 'insiden_screen.dart';
import 'tamu_screen.dart';
import 'profil_screen.dart';

class HomeShell extends StatefulWidget {
  final AppUser user;

  const HomeShell({
    super.key,
    required this.user,
  });

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();

    _pages = [
      BerandaScreen(user: widget.user),
      PatroliScreen(user: widget.user),
      InsidenScreen(user: widget.user),
      TamuScreen(user: widget.user),
      ProfilScreen(user: widget.user),
    ];
  }

  // ============================================================
  // NAVIGASI
  // ============================================================

  void _onDestinationSelected(int index) {
    if (_index == index) return;

    setState(() {
      _index = index;
    });
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,

      // --------------------------------------------------------
      // CONTENT
      // --------------------------------------------------------

      body: IndexedStack(
        index: _index,
        children: _pages,
      ),

      // --------------------------------------------------------
      // BOTTOM NAVIGATION
      // --------------------------------------------------------

      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.surface,
            border: const Border(
              top: BorderSide(
                color: AppColors.border,
                width: 0.7,
              ),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.04),
                blurRadius: 12,
                offset: const Offset(0, -3),
              ),
            ],
          ),
          child: NavigationBar(
            selectedIndex: _index,
            onDestinationSelected: _onDestinationSelected,

            // --------------------------------------------------
            // APPEARANCE
            // --------------------------------------------------

            backgroundColor: AppColors.surface,
            surfaceTintColor: Colors.transparent,
            shadowColor: Colors.transparent,
            elevation: 0,

            height: 68,

            indicatorColor: AppColors.primary.withValues(alpha: 0.12),

            labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,

            // --------------------------------------------------
            // DESTINATIONS
            // --------------------------------------------------

            destinations: const [
              NavigationDestination(
                icon: Icon(
                  Icons.home_outlined,
                  size: 23,
                ),
                selectedIcon: Icon(
                  Icons.home_rounded,
                  size: 24,
                ),
                label: 'Beranda',
              ),
              NavigationDestination(
                icon: Icon(
                  Icons.qr_code_scanner_outlined,
                  size: 23,
                ),
                selectedIcon: Icon(
                  Icons.qr_code_scanner_rounded,
                  size: 24,
                ),
                label: 'Patroli',
              ),
              NavigationDestination(
                icon: Icon(
                  Icons.warning_amber_outlined,
                  size: 23,
                ),
                selectedIcon: Icon(
                  Icons.warning_amber_rounded,
                  size: 24,
                ),
                label: 'Insiden',
              ),
              NavigationDestination(
                icon: Icon(
                  Icons.groups_outlined,
                  size: 23,
                ),
                selectedIcon: Icon(
                  Icons.groups_rounded,
                  size: 24,
                ),
                label: 'Tamu',
              ),
              NavigationDestination(
                icon: Icon(
                  Icons.person_outline_rounded,
                  size: 23,
                ),
                selectedIcon: Icon(
                  Icons.person_rounded,
                  size: 24,
                ),
                label: 'Profil',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
